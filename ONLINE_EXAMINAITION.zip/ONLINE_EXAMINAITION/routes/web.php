<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//auth route for both 
Route::group(['middleware' => ['auth']], function() { 
    Route::get('/dashboard', 'App\Http\Controllers\DashboardController@index')->name('dashboard');
});

// for users
Route::group(['middleware' => ['auth', 'role:user']], function() { 
    Route::get('/dashboard/myprofile', 'App\Http\Controllers\DashboardController@myprofile')->name('dashboard.myprofile');
    Route::get('/subject/{subjects}','App\Http\Controllers\ButtonController@index1')->name('subject');
    Route::get('/subject/{subjects}/{Tfirstname}/{Tsecondname}','App\Http\Controllers\ButtonController@index2')->name('subject');
    Route::get('/subject/dashboard/results','App\Http\Controllers\ResultController@index')->name('dashboard.results');
    Route::post('/subject/dashboard/results','App\Http\Controllers\ResultController@store')->name('dashboard.results');
   

});

// for blogwriters
Route::group(['middleware' => ['auth', 'role:blogwriter']], function() { 
    Route::get('/dashboard/postcreate', 'App\Http\Controllers\DashboardController@postcreate')->name('dashboard.postcreate');
    Route::get('/dashboard/showQuestions','App\Http\Controllers\ResultController@showQuestions')->name('dashboard/showQuestions');
    Route::get('/edit/{question_name}','App\Http\Controllers\TeacherController@edit')->name('edit');
    Route::post('/edit/{question_name}/update','App\Http\Controllers\TeacherController@update')->name('edit');
    Route::get('/delete/{question_name}','App\Http\Controllers\TeacherController@delete')->name('edit');
    // Route::get('/dashboard/studentResults','App\Http\Controllers\ResultController@showresult')->name('dashboard/studentResults');
    Route::post('/teacher', 'App\Http\Controllers\TeacherController@store');
    Route::post('/examNow','App\Http\Controllers\TeacherController@examNow');


});
//for admin
Route::group(['middleware' => ['auth', 'role:admin']], function() { 
    Route::get('/dashboard/addDepartments','App\Http\Controllers\Auth\RegisteredUserController@createDepartments')->name('dashboard/addDepartments');
    Route::get('/dashboard/addCourses','App\Http\Controllers\Auth\RegisteredUserController@createCourses')->name('dashboard/addCourses');
    Route::get('/dashboard/registerteacher','App\Http\Controllers\Auth\RegisteredUserController@createteacher')->name('dashboard/registerteacher');
    Route::get('/dashboard/registerstudent','App\Http\Controllers\Auth\RegisteredUserController@createstudent')->name('dashboard/registerstudent');
    Route::post('/add/departments','App\Http\Controllers\DepartmentController@storedepartment')->name('/add/departments');
    Route::post('/add/courses','App\Http\Controllers\CourseController@storecourse')->name('/add/courses');
    Route::post('/register/teacher', 'App\Http\Controllers\Auth\RegisteredUserController@storeteacher')->name('register/teacher');
    Route::post('/register/student', 'App\Http\Controllers\Auth\RegisteredUserController@storestudent')->name('register/student');
    Route::get('/edit2/{emails}','App\Http\Controllers\TeacherController@edit2')->name('edit2');
    Route::post('/edit2/{emails}/update','App\Http\Controllers\TeacherController@update2')->name('edit2');
    Route::post('/edit2/{emails}/update2','App\Http\Controllers\TeacherController@update3')->name('edit2');
    Route::get('/delete2/{emails}','App\Http\Controllers\TeacherController@delete2')->name('delete2');
    Route::get('/delete3/{emails}','App\Http\Controllers\TeacherController@delete3')->name('delete3');
});

require __DIR__.'/auth.php';
