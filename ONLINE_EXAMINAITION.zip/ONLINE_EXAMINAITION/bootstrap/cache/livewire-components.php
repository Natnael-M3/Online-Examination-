<?php return array (
  'actions' => 'App\\Http\\Livewire\\Actions',
  'show-posts' => 'App\\Http\\Livewire\\ShowPosts',
);