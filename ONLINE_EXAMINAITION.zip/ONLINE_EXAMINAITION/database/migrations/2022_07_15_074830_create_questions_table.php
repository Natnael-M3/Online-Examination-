<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuestionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id');
            $table->string('Teacher_name');
            $table->string('Teacher_email');
            $table->string('Course_Name');
            // $table->foreign('Course_Name')->references('Coursename')->on('users');
            $table->string('Dep_Name');
            $table->longText('chooseQuestion')->nullable();
            $table->longText('shortAnswerQuestion')->nullable();
            $table->string('choice1')->nullable();
            $table->string('choice2')->nullable();
            $table->string('choice3')->nullable();
            $table->string('choice4')->nullable();
            $table->string('chooseAnswer')->nullable();
            $table->longText('shortAnswer')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('questions');
    }
}
