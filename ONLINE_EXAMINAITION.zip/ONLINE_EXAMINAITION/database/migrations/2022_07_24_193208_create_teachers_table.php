<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTeachersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teachers', function (Blueprint $table) {
            $table->increments('id');
            $table->string('Teacher_name');
            $table->string('Teacher_email');
            $table->string('Student_email');
            $table->string('Student_Fname');
            $table->string('Student_Lname');
            $table->string('Student_id');
            $table->string('Course_name');
            $table->integer('result')->nullable();
            $table->timestamps();
            // $table->foreign('F_Result')->references('Result')->on('id')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teachers');
    }
}
