<div>
    <?php echo e(Request::segment(3)); ?>

    <?php echo e(Request::segment(4)); ?>

</div><?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/layouts/questions.blade.php ENDPATH**/ ?>