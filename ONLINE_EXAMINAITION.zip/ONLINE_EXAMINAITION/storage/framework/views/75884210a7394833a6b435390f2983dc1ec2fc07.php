<div class="flex flex-col items-center mt-0">
    <div class=" bg-slate-700 flex justify-center sm:max-w-md  px-6 py-0 shadow-md overflow-hidden sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/components/auth-card-2.blade.php ENDPATH**/ ?>