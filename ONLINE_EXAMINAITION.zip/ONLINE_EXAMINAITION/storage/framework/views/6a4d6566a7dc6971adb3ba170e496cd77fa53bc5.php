<div>
    hi nati
</div><?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/layouts/showresult.blade.php ENDPATH**/ ?>