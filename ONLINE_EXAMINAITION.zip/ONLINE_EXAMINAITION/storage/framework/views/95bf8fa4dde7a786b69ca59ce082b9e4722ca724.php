<div>
    
    <button type="button" wire:click="add(5,7)">sum</button><br>
    Result: <?php echo e($sum); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/livewire/actions.blade.php ENDPATH**/ ?>