<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard for admin')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 ">

            <?php if(DB::table('users')->select('Fname')->where('tags', null)->count() > 1): ?>
                <h1 class="underline text-center">Teachers</h1><br>
                <table class="flex justify-center">
                    <tr>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            First_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            Last_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Email</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Department
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Course
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Manage
                        </th>
                    </tr>

                    <?php for($i = 1;
    $i <
    DB::table('users')->select('Fname')->where('tags', null)->count();
    $i++): ?>
                        <tr>
                            <td class="border-2 pl-2 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Fname')->where('tags', null)->pluck('Fname')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Lname')->where('tags', null)->pluck('Lname')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Depname')->where('tags', null)->pluck('Depname')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Coursename')->where('tags', null)->pluck('Coursename')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <a
                                    href="/edit2/<?php echo e(DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i)); ?>">Edit</a>
                                <a
                                    href="/delete2/<?php echo e(DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i)); ?>">
                                    Delete</a>
                            </td>
                        </tr>
                    <?php endfor; ?>

                </table><br>
            <?php endif; ?>


            <?php if(DB::table('users')->select('Fname')->where('Coursename', null)->count() > 1): ?>
                <h1 class="underline text-center">Students</h1><br>
                <table class="flex justify-center">
                    <tr>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            First_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            Last_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            ID</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Email</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Department
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Manage
                        </th>
                    </tr>

                    <?php for($i = 1;
    $i <
    DB::table('users')->select('Fname')->where('Coursename', null)->count();
    $i++): ?>
                        <tr>
                            <td class="border-2 pl-2 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Fname')->where('Coursename', null)->pluck('Fname')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Lname')->where('Coursename', null)->pluck('Lname')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('stud_id')->where('Coursename', null)->pluck('stud_id')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i)); ?>

                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <?php echo e(DB::table('users')->select('Depname')->where('Coursename', null)->pluck('Depname')->get($i)); ?>

                            </td>

                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <a
                                    href="/edit2/<?php echo e(DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i)); ?>">Edit</a>
                                <a
                                    href="/delete3/<?php echo e(DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i)); ?>">
                                    Delete</a>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </table><br>
            <?php endif; ?>





        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/dashboard.blade.php ENDPATH**/ ?>