
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Teacher Selections</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
</head>

<body>
    
    <a href="/dashboard" class="ml-3 mt-0 text-black"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
    
    <?php if($show == 1): ?>
        <div class="flex ml-8 mr-8 flex-row justify-center h-36 mt-24  shadow-xl rounded-lg">
            <p class="mt-14">No Questions are added on this course to you</p>
        </div>
    <?php elseif($show == 3): ?>
        <div class="flex ml-8 mr-8 flex-row justify-center h-36 mt-24  shadow-xl rounded-lg">
            <p class="mt-14">You Inserted the exam or The exam is not activate by your teacher </p>
        </div>
    <?php elseif($show == 4): ?>
        <div class="flex ml-8 mr-8 flex-row justify-center h-36 mt-24  shadow-xl rounded-lg">
            <p class="mt-14">Sorry you have no teacher for this course</p>
        </div>
    <?php else: ?>
        <p id="countv" hidden>
            <?php echo e($count = DB::table('questions')->where('Teacher_email', $email)->get()->count()); ?></p>

        <form action="dashboard/results" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>


            <input hidden type="text" name="Course_name" value=<?php echo e($subject); ?>>
            <input hidden type="text" name="Teacher_name" value=<?php echo e($Teacher_name); ?>>
            <input hidden type="text" name="Teacher_email" value=<?php echo e($email); ?>>
            <input hidden type="text" name="Student_email" value=<?php echo e($Student_email); ?>>
            <input hidden id='value' type="text" name="result">
            <input hidden type="text" name="Student_Fname" value="<?php echo e(Auth::user()->Fname); ?>">
            <input hidden type="text" name="Student_Lname" value="<?php echo e(Auth::user()->Lname); ?>">
            <input hidden type="text" name="Student_id" value="<?php echo e(Auth::user()->stud_id); ?>">
            <input hidden id='check' type="text" name="checkinserted">

            <div id="alls" class="ml-6 mt-12  sm:ml-12  shadow-2xl shadow-slate-300 w-11/12">
                <?php $__currentLoopData = DB::table('questions')->select('chooseQuestion', 'choice1', 'choice2', 'choice3', 'choice4', 'chooseAnswer')->where('Course_Name', $subject)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="ml-2 sm:ml-24">
                        <tr class="ml-2 sm:ml-24">
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="ml-2 sm:ml-24">.<?php echo e($selection->chooseQuestion); ?></td>
                        </tr>
                    </div>



                    <div id="form">
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceA<?php echo e($loop->iteration); ?>" value="A"> A.<span>
                                <?php echo e($selection->choice1); ?></span></div>
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceB<?php echo e($loop->iteration); ?>" value="B"> B.<span>
                                <?php echo e($selection->choice2); ?></span></div>
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceC<?php echo e($loop->iteration); ?>" value="C"> C.<span>
                                <?php echo e($selection->choice3); ?></span></div>
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceD<?php echo e($loop->iteration); ?>" value="D"> D.<span>
                                <?php echo e($selection->choice4); ?></span></div>
                        <div hidden><span id="answer<?php echo e($loop->iteration); ?>"><?php echo e($selection->chooseAnswer); ?></span>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="flex flex-row items-center justify-center">
                <button id="submit" value=0 name="isActivated"
                    class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded-full mt-6 w-1/2 sm:w-2/5">Submit</button>
            </div>

        </form>

    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.notify_message1','data' => []]); ?>
<?php $component->withName('notify_message1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</body>
<script>
    document.getElementById('submit').onclick = function() {

        var inputs = document.querySelector("#form");
        var alls = document.querySelector("#alls");
        var countv = document.querySelector("#countv");
        let show = countv.innerHTML;
        let values = document.querySelector('#value');
        let check = document.querySelector('#check');

        console.log(show);
        var count = 0;
        let isclicked = 1;
        // console.log(show);
        console.log(alls.children)
        console.log(alls.children[1].children[0].children[0]);
        for (let j = 1; j < show * 2; j = j + 2) {
            for (let i = 0; i < 4; i++) {
                if (alls.children[j].children[i].children[0].type == 'radio' && alls.children[j].children[i]
                    .children[0].checked) {
                    count++;
                    console.log(count);
                }
            }
        }
        console.log(count);

        let val = 0;
        for (i = 1; i < show * 2; i = i + 2) {
            let names;
            let answer;
            for (j = 0; j < 4; j++) {
                //    console.log( alls.children[i].children[j].children[0].name);
                names = alls.children[i].children[j].children[0].name;
                if (j = 3) {
                    answer = alls.children[i].children[4].children[0].innerHTML;
                }
                // console.log(names);
                // console.log(answer);
            }

            let radios = document.getElementsByName(names)
            // console.log(radios);
            // console.log(show);
            if (count == show) {
                for (let radio of radios) {
                    if (radio.checked) {
                        if (radio.value == answer) {
                            val = val + 1;
                        }
                        // else{
                        //     alert('you do not got the answer')
                        // }  
                    }
                }
            }
        }

        if (count != show) {
            //  alert("Please fill all answers");
            isclicked = 0;
        } else {
            // alert('you Score ' + val + ' out of ' + show + ' questions ')
            isclicked = 1;
        }
        values.value = val;
        check.value = isclicked;
    }
</script>

</html>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/layouts/toshow.blade.php ENDPATH**/ ?>