<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard for user')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="flex flex-row justify-center mb-10">
            <h1 class="font-serif text-xl">Your results are below</h1>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            
            

            <table class="flex justify-center">
                <tr>
                    <?php $__currentLoopData = DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            <?php echo e($courses); ?>

                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(DB::table('teachers')->select('result')->count() > 0): ?>
                            <?php if(DB::table('teachers')->select('result')->where('Course_name', $courses)->where('Student_email', Auth::user()->email)->count() > 0): ?>
                                <td class="border-2 px-5 py-2 border-slate-700">
                                    <?php echo e(DB::table('teachers')->select('result')->where('Course_name', $courses)->where('Student_email', Auth::user()->email)->value('result')); ?>

                                </td>
                            <?php else: ?>
                                <td class="border-2 px-5 py-2 border-slate-700">0</td>
                            <?php endif; ?>
                        <?php else: ?>
                            <td class="border-2 px-5 py-2 border-slate-700">0</td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </table>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/myprofile.blade.php ENDPATH**/ ?>