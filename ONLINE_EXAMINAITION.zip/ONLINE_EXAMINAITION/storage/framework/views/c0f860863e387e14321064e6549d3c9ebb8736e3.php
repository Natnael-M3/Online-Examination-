<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard for Teacher')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">


            <div>
                

                <?php if(DB::table('activations')->select('Student_email')->where('Teacher_email', Auth::user()->email)->count() > 0): ?>
                    <table class="flex justify-center">
                        <tr>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student first_name</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student last_name</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student id</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student email</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Result
                            </th>
                        </tr>

                        <?php $__currentLoopData = DB::table('activations')->select('Student_email')->where('Teacher_email', Auth::user()->email)->pluck('Student_email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border-2 px-5 py-2 border-slate-700">
                                    <?php echo e(DB::table('users')->select('Fname')->where('email', $teacher_students)->value('Fname')); ?>

                                </td>
                                <td class="border-2 px-5 py-2 border-slate-700">
                                    <?php echo e(DB::table('users')->select('Lname')->where('email', $teacher_students)->value('Lname')); ?>

                                </td>
                                <td class="border-2 px-5 py-2 border-slate-700">

                                    <?php echo e(DB::table('users')->select('stud_id')->where('email', $teacher_students)->value('stud_id')); ?>

                                </td>
                                <td class="border-2 px-5 py-2 border-slate-700">

                                    <?php echo e(DB::table('users')->select('email')->where('email', $teacher_students)->value('email')); ?>

                                </td>
                                <?php if(DB::table('teachers')->select('result')->where('Student_email', $teacher_students)->where(
                                        'Course_name',
                                        DB::table('users')->select('Coursename')->where('email', Auth::user()->email)->value('Coursename'))->count() > 0): ?>
                                    <td class="border-2 px-5 py-2 border-slate-700">
                                        <?php echo e(DB::table('teachers')->select('result')->where('Student_email', $teacher_students)->where('Course_name',DB::table('users')->select('Coursename')->where('email', Auth::user()->email)->value('Coursename'))->value('result')); ?>

                                    </td>
                                <?php else: ?>
                                    <td class="border-2 px-5 py-2 border-slate-700">
                                        0
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/blogwriterdash.blade.php ENDPATH**/ ?>