
<div>
   <a  href="/maths" ><?php echo e($title); ?></a><br><br>
</div><?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/components/courses.blade.php ENDPATH**/ ?>