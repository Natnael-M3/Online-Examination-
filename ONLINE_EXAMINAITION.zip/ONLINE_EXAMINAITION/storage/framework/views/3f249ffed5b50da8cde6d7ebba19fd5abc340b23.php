<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>show question</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
</head>

<body>
    <div>
        <a href="/dashboard" class="ml-3  text-black "><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

        <?php if(DB::table('questions')->select('Teacher_email')->where('Teacher_email', Auth::user()->email)->count() > 0): ?>

            <div id="alls" class="ml-5 sm:ml-20 sm:w-10/12	sm:shadow-2xl shadow-stone-400 rounded-lg ">
                <?php $__currentLoopData = DB::table('questions')->select('chooseQuestion', 'choice1', 'choice2', 'choice3', 'choice4', 'chooseAnswer')->where('Teacher_email', Auth::user()->email)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <hr class="border-1 border-cyan-600">
                    <div class="sm:ml-24">
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="ml-32">.<?php echo e($selection->chooseQuestion); ?></td>
                        </tr>
                    </div>

                    <div id="form" class=" sm:ml-32">
                        <div><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceA<?php echo e($loop->iteration); ?>" value="A"> A.<span>
                                <?php echo e($selection->choice1); ?></span></div>
                        <div><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceB<?php echo e($loop->iteration); ?>" value="B"> B.<span>
                                <?php echo e($selection->choice2); ?></span></div>
                        <div><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceC<?php echo e($loop->iteration); ?>" value="C"> C.<span>
                                <?php echo e($selection->choice3); ?></span></div>
                        <div><input type="radio" name="question<?php echo e($loop->iteration); ?>"
                                id="choiceD<?php echo e($loop->iteration); ?>" value="D"> D.<span>
                                <?php echo e($selection->choice4); ?></span></div>
                        <div><span>Answer: </span><span
                                id="answer<?php echo e($loop->iteration); ?>"><?php echo e($selection->chooseAnswer); ?></span></div>
                    </div>
                    <hr class="border-1 border-cyan-600">
                    <div class="ml-32 sm:ml-60 flex sm:gap-1 sm:flex-row flex-col gap-2 ">
                        <a href="/edit/<?php echo e($selection->chooseQuestion); ?>">
                            <i class="fas fa-edit"></i> edit</a>
                        <a href="/delete/<?php echo e($selection->chooseQuestion); ?>"class=" sm:ml-40">
                            <i class="fa fa-trash" aria-hidden="true"></i> delete
                        </a>
                    </div>

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <form action="/examNow" method="POST">
                <?php echo csrf_field(); ?>
                <div class="flex flex-col sm:flex-row gap-2 sm:gap-4">
                    <button id="button1"
                        class="mt-4 sm:ml-24 ml-2 w-11/12 sm:w-1/4  bg-green-600 hover:bg-green-800 text-white font-bold py-2 px-4 rounded-full"
                        value="1" name="isActivated">Send exam now</button>
                    <button id="button2"
                        class="mt-4 ml-2 w-11/12 sm:w-1/4 bg-green-600 hover:bg-green-800 text-white font-bold py-2 px-4 rounded-full"
                        value="0" name="isActivated">Don't send exam now</button>
                </div>

            </form>
        <?php else: ?>
            <p>No questions added</p>
        <?php endif; ?>

    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.notify_message','data' => []]); ?>
<?php $component->withName('notify_message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/layouts/showQuestion.blade.php ENDPATH**/ ?>