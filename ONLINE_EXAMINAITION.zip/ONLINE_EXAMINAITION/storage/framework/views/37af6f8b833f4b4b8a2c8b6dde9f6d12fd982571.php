<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>edit</title>
     
      <script src="//unpkg.com/alpinejs" defer></script>  
     <script src="https://cdn.tailwindcss.com"></script>
    <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
          }
        }
      }
    }
  </script>
  
</head>
<body  style="background-image: url('https://wallpaperaccess.com/full/12313.jpg')" >
  
<main>
   <section class="max-h-screen  w-full bg-center bg-no-repeat bg-cover" >
     
            <form action="/edit/<?php echo e($question_name); ?>/update" method="POST" class="formclass" enctype="multipart/form-data" >
              
               <?php echo csrf_field(); ?>
               
               <div class="flex flex-col gap-y-4 justify-center  mt-20 ">

               <div class="flex flex row justify-center gap-x-8 w-full">
                  <label for="quetion1" class="text-white">Question :</label>
                  <input type="text" name="chooseQuestion" class="bg-white w-2/5 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" 
                   value="<?php echo e(DB::table('questions')->select('chooseQuestion')->where('chooseQuestion',$question_name)->value('chooseQuestion')); ?>" required>
            
               </div >
               <div class="flex flex-col gap-y-4 justify-center w-full">
                  <div class="flex flex row justify-center gap-x-8 gap-y-4  w-full">
                     <label for="choice1" class="text-white	">Choice A:</label>
                     <input type="text" name="choice1" class="bg-white w-1/4 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" 
                      value="<?php echo e(DB::table('questions')->select('choice1')->where('chooseQuestion',$question_name)->value('choice1')); ?>" required>
              
                  </div>
                  <div  class="flex flex row justify-center gap-x-8 gap-y-4  w-full">
                     <label for="choice2" class="text-white	">Choice B:</label>
                     <input type="text" name="choice2" class="bg-white w-1/4 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" 
                      value="<?php echo e(DB::table('questions')->select('choice2')->where('chooseQuestion',$question_name)->value('choice2')); ?>" required>
                   
                  </div>   
                  <div  class="flex flex row justify-center gap-x-8 w-full">
                     <label for="choice3" class="text-white	">Choice C:</label>
                     <input type="text" name="choice3"class="bg-white w-1/4 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" 
                      value="<?php echo e(DB::table('questions')->select('choice3')->where('chooseQuestion',$question_name)->value('choice3')); ?>" required>
                   
                  </div>
                  <div  class="flex flex row justify-center gap-x-8 w-full">
                     <label for="choice1" class="text-white	">Choice D:</label>
                     <input type="text" name="choice4" class="bg-white w-1/4 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" 
                      value="<?php echo e(DB::table('questions')->select('choice4')->where('chooseQuestion',$question_name)->value('choice4')); ?>" required>
                
                  </div>
                  <div  class="flex flex row justify-center gap-x-8 w-full">
                     <label for="choice1" class="text-white	">Solution :</label>
                     <input type="text" name="chooseAnswer" class="bg-white w-1/6 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm" 
                     value="<?php echo e(DB::table('questions')->select('chooseAnswer')->where('chooseQuestion',$question_name)->value('chooseAnswer')); ?>" required>
                 
                  </div>
                  <div  class="flex flex row justify-center gap-x-8 w-full">
                    <button  value = 0 name="isActivated" class="text-white italic p-2 border border-indigo-500 hover:bg-white hover:text-black hover:border-inherit" >insert choose</button>
                  </div>
               </div>
              
               <input hidden type="text" name="Teacher_name" value="<?php echo e(Auth::user()->Fname); ?>">
               <input hidden type="email" name="Teacher_email" value="<?php echo e(Auth::user()->email); ?>">
               

               
            </div>
            </form>

   </section>
   
 
</main>
  

  
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/layouts/edit.blade.php ENDPATH**/ ?>