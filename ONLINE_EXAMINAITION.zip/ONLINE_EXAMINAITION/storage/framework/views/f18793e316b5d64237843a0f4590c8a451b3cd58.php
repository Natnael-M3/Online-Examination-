<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard for user')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <p hidden>
                <?php echo e($count1 = DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->count()); ?>

            </p>
            <?php for($i = 0; $i <= $count1 - 1; $i++): ?>
                <a class="ml-2 bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                    href="/subject/<?php echo e(DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name')->get($i)); ?>"><?php echo e(DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name')->get($i)); ?></a>
            <?php endfor; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/userdash.blade.php ENDPATH**/ ?>