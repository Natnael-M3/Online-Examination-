<div class="flex flex-col items-center mt-0 ">
    <div class="w-4/5 md:w-2/6  bg-slate-700  sm:max-w-md  px-6 py-4 shadow-md overflow-hidden sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/components/auth-card-2.blade.php ENDPATH**/ ?>