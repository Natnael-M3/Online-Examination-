
<?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/components/application-logo.blade.php ENDPATH**/ ?>