<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="  h-full  bg-slate-100 ">
        <a href="/dashboard" class="ml-3 mt-0 text-black"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

        <div
            class=" p-6  mt-6 flex flex-row justify-center h-5/6	max-w-5xl mx-auto bg-slate-200 shadow-2xl shadow-slate-700">
            <div class=" w-11/12 bg-white overflow-hidden rounded-lg  ">
                <main class="h-full  flex flex-row justify-center items-center shadow-2xl bg-white	 ">

                    <form action="/teacher" method="POST" class="w-full h-full mt-0" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="flex flex-col gap-y-4 items-center justify-center w-full h-full  ">
                            <div class="flex flex-col gap-2 sm:flex-row items-center justify-center sm:gap-x-6 w-full ">
                                <label for="quetion1">Question :</label>
                                <input type="text" name="chooseQuestion"
                                    class="w-10/12 sm:w-9/12 border border-sky-500  rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-blue-500 focus:ring-blue-500 focus:ring-1 sm:text-sm"
                                    value="<?php echo e(old('chooseQuestion')); ?>" required>

                            </div>
                            <div class="flex flex-col items-center sm:gap-y-4 justify-center w-full  ">
                                <div class="flex flex-col sm:flex-row items-center justify-center sm:gap-x-8  w-full">
                                    <label for="choice1">Choice A:</label>
                                    <input type="text" name="choice1"
                                        class="w-4/5 sm:w-1/2 border border-sky-500  rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-blue-500 focus:ring-blue-500 focus:ring-1 sm:text-sm"
                                        value="<?php echo e(old('choice1')); ?>" required>

                                </div>
                                <div class="flex flex-col sm:flex-row items-center justify-center sm:gap-x-8   w-full ">
                                    <label for="choice2">Choice B:</label>
                                    <input type="text" name="choice2"
                                        class="w-4/5 sm:w-1/2 border border-sky-500  rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-blue-500 focus:ring-blue-500 focus:ring-1 sm:text-sm"
                                        value="<?php echo e(old('choice2')); ?>" required>
                                </div>
                                <div class="flex flex-col sm:flex-row items-center justify-center sm:gap-x-8   w-full ">
                                    <label for="choice3">Choice C:</label>
                                    <input type="text" name="choice3"
                                        class="w-4/5 sm:w-1/2 border border-sky-500  rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-blue-500 focus:ring-blue-500 focus:ring-1 sm:text-sm"
                                        value="<?php echo e(old('choice3')); ?>" required>

                                </div>
                                <div
                                    class="flex flex-col sm:flex-row items-center justify-center sm:gap-x-8 gap-y-1  w-full ">
                                    <label for="choice1">Choice D:</label>
                                    <input type="text" name="choice4"
                                        class="w-4/5 sm:w-1/2 border border-sky-500  rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-blue-500 focus:ring-blue-500 focus:ring-1 sm:text-sm"
                                        value="<?php echo e(old('choice4')); ?>" required>

                                </div>
                                <div
                                    class="flex flex-col sm:flex-row items-center justify-center sm:gap-x-8 gap-y-1 w-full ">
                                    <label for="choice1">Solution :</label>
                                    <input type="text" name="chooseAnswer"
                                        class="w-4/5 sm:w-1/3 border border-sky-500  rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-blue-500 focus:ring-blue-500 focus:ring-1 sm:text-sm"
                                        value="<?php echo e(old('chooseAnswer')); ?>" required>

                                </div>

                            </div>
                            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full"
                                value=0 name="isActivated">insert choose</button>

                            <input hidden type="text" name="Teacher_name" value="<?php echo e(Auth::user()->Fname); ?>">
                            <input hidden type="email" name="Teacher_email" value="<?php echo e(Auth::user()->email); ?>">

                        </div>

                    </form>
                </main>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ONLINE_EXAMINAITION\resources\views/postcreate.blade.php ENDPATH**/ ?>