<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard for New Blog post')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
      <main>
   <section class="choosesection">
      <h1>for Choose Questions</h1>
      <div class="card">
         <div class="q_card dyes" >
            <form action="/teacher" method="POST" class="formclass" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <div class="labelandinput1">
                  <label for="quetion1" class="labelclass">Question :</label>
                  <input type="text" name="chooseQuestion" class="inputclass1" value="<?php echo e(old('chooseQuestion')); ?>" required>
            
               </div>
               <div class="labelandinput2">
                  <div class="labelandinput1">
                     <label for="choice1">Choice A:</label>
                     <input type="text" name="choice1" class="inputclass2" value="<?php echo e(old('choice1')); ?>" required>
              
                  </div>
                  <div class="labelandinput1">
                     <label for="choice2">Choice B:</label>
                     <input type="text" name="choice2" class="inputclass2" value="<?php echo e(old('choice2')); ?>" required>
                     <?php $__errorArgs = ['choice2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p class="showerror"><?php echo e($message); ?></p>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>   
                  <div class="labelandinput1">
                     <label for="choice3">Choice C:</label>
                     <input type="text" name="choice3" class="inputclass2" value="<?php echo e(old('choice3')); ?>" required>
                   
                  </div>
                  <div class="labelandinput1">
                     <label for="choice1">Choice D:</label>
                     <input type="text" name="choice4" class="inputclass2" value="<?php echo e(old('choice4')); ?>" required>
                
                  </div>
                  <div class="labelandinput1">
                     <label for="choice1">Solution :</label>
                     <input type="text" name="chooseAnswer" class="inputclass2" value="<?php echo e(old('chooseAnswer')); ?>" required>
                 
                  </div>
                  
               </div>
               <button class="buttonclass" value = 0 name="isActivated">insert choose</button>
               <input hidden type="text" name="Teacher_name" value="<?php echo e(Auth::user()->Fname); ?>">
               <input hidden type="email" name="Teacher_email" value="<?php echo e(Auth::user()->email); ?>">
              
            </form>
         </div>
      </div>
   </section>
   
 
</main>
  
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Laravel-8-multi-auth-main\resources\views/postcreate.blade.php ENDPATH**/ ?>