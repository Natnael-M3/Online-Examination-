<?php

namespace App\Http\Controllers;

use Mockery\Undefined;
use App\Models\Results;

use App\Models\Teachers;
use App\Models\Activations;
use Illuminate\Http\Request;
use PhpParser\Node\Stmt\Foreach_;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;
use function PHPUnit\Framework\isEmpty;
use Illuminate\Support\Facades\Session;


class ResultController extends Controller
{
    //
    public function index(){
        return view('layouts.toshow');
    }
    
  public function store(Request $request){
        
        // dd($request->all());
        if($request->checkinserted == '0'){
            // dd('no hi');
                   return back()->with('message','please insert all chooses');
        }
        else{
            // dd('hi');
            //    dd(Auth::user()->stud_id);
                $affect_db = DB::table('activations')
              ->where('Student_email', $request->Student_email)
              ->where('Teacher_email', $request->Teacher_email)
              ->update(['isActivated' => $request->isActivated]);
            $count = 0;
            
            $stud_email = DB::table('teachers')->select('Student_email')->where('Student_email',Auth::user()->email)->where('Course_name',$request->Course_name)->value('Student_email');

            if(empty($stud_email)){
                 $insertValues = $request->validate([
            'Teacher_name' => 'required',
            'Teacher_email'=> 'required',
            'Student_Fname' => 'required',
            'Student_Lname' => 'required',
            'Student_email'=>'required',
            'Student_id'=> 'required',
            'Course_name'=>'required',
            'result' => 'required',
            ]);
            Teachers::create($insertValues);
            return redirect('/dashboard')->with('message','Result inserted Successfully!');   
            }
            else{
                $affecteds = DB::table('teachers')->where('Student_email',Auth::user()->email)->where('Course_name',$request->Course_name)
                ->update(['result' => $request->result]);
                     return redirect('/dashboard')->with('message','Result inserted Successfully!');  
            }
                   
        }
    }
  
    public function showQuestions(){
        return view('layouts.showQuestion');
    }
    
}