<?php

namespace App\Http\Controllers;

use App\Models\Courses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

use function GuzzleHttp\Promise\all;

class ButtonController extends Controller
{
    //
    public function index1(Request $request){
       
        $array = explode(',',Auth::user()->tags);
       $coursename = last(request()->segments());
        $teachers = DB::table('users')->select('email')->where('Coursename',$coursename)->pluck('email');
        $counting = 0;
        // dd($teachers);
        for($i=0 ; $i<count($teachers) ; $i++){
            if(empty(DB::table('activations')->select('Teacher_email')->where('Student_email',Auth::user()->email)->where('Teacher_email',$teachers[$i])->value('Teacher_email'))){
                $counting = $counting + 1;
            }
        }
        // dd($counting);
          if(count($teachers) != $counting){
            
                for($i=0;$i<count($array);$i++){
            if(DB::table('users')->select('Coursename')->where('email',$array[$i])->value('Coursename')==last(request()->segments())){
                 if(DB::table('questions')->select('Teacher_email')->where('Teacher_email',$array[$i])->count() > 0){
                        // dd("so the email is $array[$i]");
                $Teacher_name = DB::table('users')->select('Fname')->where('email',$array[$i])->value('Fname');
                $Student_email = Auth::user()->email;
                $checkAvailable = DB::table('teachers')->select('Course_name')->where('Student_email',Auth::user()->email)->where('Teacher_email',$array[$i])->value('Course_name')== last(request()->segments());
                // dd($checkAvailable);
                $isitempty = empty(DB::table('teachers')->select('Course_name')->where('Student_email',Auth::user()->email)->where('Teacher_email',$array[$i])->value('Course_name')== last(request()->segments()));
                $checkActivation = DB::table('activations')->where('Student_email',Auth::user()->email)->where('Teacher_email',$array[$i])->value('isActivated');
                // dd($checkActivation);
                if( $checkActivation == 0 && $isitempty || $checkActivation==0 && $checkAvailable ){
                   
                      return view('layouts.toshow',[
                        'show'=> 3
                    ]);

                }
      
                else{
                     return view('layouts.toshow',[
                    'show'=> 2,
                    'email' => $array[$i],
                    'subject'=> last(request()->segments()),
                    'Teacher_name'=>$Teacher_name,
                    'Student_email'=>$Student_email,
                    
                ]);

                } 
              }
                else{
                // dd('no hi');
                 return view('layouts.toshow',[
                     'show' => 1
                ]);
                 }
           
            }
           
        }
          }
          else{
       
            return view('layouts.toshow',[
                    
                     'show' => 4
               ]);
          }    
    }
    public function index2(){
        return view('layouts.questions');
    }
}
