<?php

namespace App\Http\Controllers;

use App\Models\Departments;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    //
    public function storedepartment(Request $request){
        // dd($request->all());
         $formFields = $request->validate([
            'dep_name' => 'required|unique:departments,dep_name|max:50',
        ]);
        Departments::create($formFields);
        return back()->with('message','Department inserted successfully!');
    }
}
