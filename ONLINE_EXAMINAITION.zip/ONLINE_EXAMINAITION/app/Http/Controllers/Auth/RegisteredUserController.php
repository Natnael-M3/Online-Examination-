<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\Activations;

use function GuzzleHttp\Promise\all;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\Registered;
use App\Providers\RouteServiceProvider;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function createDepartments(){
        return view('auth.addDepartments');
    }
    public function createCourses(){
        return view('auth.addCourses');
    }
       public function createadmin()
    {
        return view('auth.registeradmin');
    }
    public function createteacher()
    {
        return view('auth.registerteacher');
    }
       public function createstudent()
    {
        return view('auth.registerstudent');
    }
    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    
    public function storeteacher(Request $request)
    {
        
        $count1 = DB::table('courses')->count();
        $count2 = 0;
        for ($i=0; $i<=$count1-1; $i++){
            if(DB::table('courses')->select('course_name')->where('dep_name',$request->Depname)->pluck('course_name')->get($i)== $request->Coursename){
                // dd('sucessful');
                $count2 = $count2 + 1;
                // dd($count2);
            }
        }
       if($count2 == 1){
           $request->validate([
                    'Fname' => 'required|string|max:255',
                    'Lname' => 'required|string|max:255',
                    'Depname' => 'required|string|max:255',
                    'Coursename' => 'required|string|max:255',
                    'email' => 'required|string|email|max:255|unique:users',
                    'password' => 'required|string|confirmed|min:8',
                ]);

                    $user = User::create([
                    'Fname' => $request->Fname,
                    'Lname' => $request->Lname,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'Depname' => $request->Depname,
                    'Coursename' => $request->Coursename,
                ]);
                    $user->attachRole($request->role_id); 
                    event(new Registered($user));
                    return back()->with('message','Teacher registered successfully!');

                    // return redirect('/dashboard')->with('message','Teacher registered successfully!');

       }
       else{
            return back()->with('message','please match the courses with the departments!!!');
       }
        
    }

       public function storestudent(Request $request)
    {
 
        $teachers = $request->tags;
        $commas = explode(",", $teachers);
        $count = 0;
        $cofcount = 0;
        for($i=0 ; $i<=count($commas)-1 ; $i++){
                $comma_0 = explode(" ", $commas[$i]); 
                $count_comma_0 = count($comma_0);
                if(count($comma_0)==1){
                    if(Str::contains($comma_0[0],['@'])){
                        $count = $count + 1;
                    }
                  
                }
                else{
                    $cofcount = $cofcount + 1;
                }
        }
    // dd($cofcount);
    $check = false;
    if($cofcount == 0){
     
        if($count==count($commas)){
            $check = true;
        }
        else{
            // dd('please write correctly or include @ in all email names');
            return redirect()->back()->withInput()->with('message',"please write correctly or include @ in all email names");

        }
    }
    else{
        // dd('please do not use spaces ');
        return redirect()->back()->withInput()->with('message',"please do not use spaces");

    }
  

//-----------------------------------------------------------------Second Step-----------------------------------
        $value = 0;
        $values = 0;
        if($check){
            for($i=0 ; $i<=count($commas)-1 ; $i++){
                $spaces = explode(" ", $commas[$i]);
                $bool1 = !empty(DB::table('users')->select('email')->where('email',$spaces[0])->pluck('email')->get(0));
                // dd($bool1);
                if($bool1){
                    $value = $value + 1;
                }
            }
            // dd($value);
            if($value == count($commas) ){
                   for($i=0 ; $i<=count($commas)-1 ; $i++){
                        $spaces = explode(" ", $commas[$i]);
                        $bool1 = DB::table('users')->select('Depname')->where('email',$spaces[0])->pluck('Depname')->get(0);
                        // dd($bool1);
                        if($request->Depname == $bool1){
                            $bools = empty(DB::table('users')->select('Coursename')->where('email',$spaces[0])->pluck('Coursename')->get(0));
                            // dd($bools);
                            if($bools){
                                $values = $values + 1;
                            }
                        }
                        else{
                           
                            $request->validate([
                            'Depname'=> 'required|string|max:255',
                            'tags'=>'required',
                            ]);   
                            //  dd('sorry sorry some teachers are not department');          
                            return redirect()->back()->withInput()->with('message',"sorry some teachers are not department of => $request->Depname");
                        }
              }
            }
            else{
                // dd('some of emails are not available in db');
                return redirect()->back()->withInput()->with('message',"some of emails are not available in db");

            }
        
    }
      
        
        //-------------------------------------- The Working Stage------------------------------
        // dd($values);
        if($values == 0){
           
            $counts = DB::table('users')->select('Coursename')->where('Depname',$request->Depname)->count();
            $arrays = [];
            $array = [];
            for($i=0 ; $i<=count($commas)-1 ; $i++){
                $spaces = explode(" ", $commas[$i]);
                $fname = DB::table('users')->select('Coursename')->where('email',$spaces[0])->pluck('Coursename')->get(0);
                if($fname){
                    array_push($array,$fname);
                }            
        }
        //  dd($array);
         $unique = array_unique($array);
        //  dd($unique);
         if(count($unique) == count($array)){
                $arrays = DB::table('users')->select('stud_id')->pluck('stud_id');
                
                $val = 0;
                for($k=0 ; $k < count($arrays) ; $k++){
                    if($request->stud_id != null){
                        if($arrays[$k]== $request->stud_id){
                        $val = $val + 1;
                        }
                    }
                }
                if($val == 1){
                    return redirect()->back()->withInput()->with('message',"the stud_id must be unique");
                }
                
                $teacher_emails = [];
                $teacher_emails2 = [];
                $teacher_emails3 = [];
                $dep_name = DB::table('users')->select('email')->where('Depname',$request->Depname)->pluck('email');
                $dep_name2 = DB::table('users')->select('email')->where('Depname',$request->Depname)->where('Coursename', null)->pluck('email') ;
                $num = count($dep_name);
                $num2 = count($dep_name2);
                for($p=0; $p<$num ; $p++){
                    array_push($teacher_emails,$dep_name[$p]);
                }
                for($q=0; $q<$num2 ; $q++){
                    array_push($teacher_emails2,$dep_name[$q]);
                }
                $counter = 0;
               for($r=0; $r<$num ; $r++){
                   for($s=0; $s<$num2 ; $s++){
                    if($dep_name[$r] != $dep_name2[$s]){
                        $counter = $counter + 1;
                    }
                }
                if($counter == $num2){
                    array_push($teacher_emails3,$dep_name[$r]);
                }
                  $counter = 0;
                }
                $insertedtags = explode(',',$request->tags);
                if($insertedtags == $teacher_emails3){
                   
                      $request->validate([
                'Fname' => 'required|string|max:255',
                'Lname' => 'required|string|max:255',
                'stud_id'=>'required|string|max:255',
                'Depname'=> 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'tags'=>'required',
                'password' => 'required|string|confirmed|min:8',
            ]);
                $user = User::create([
                'Fname' => $request->Fname,
                'Lname' => $request->Lname,
                'stud_id'=>$request->stud_id,
                'Depname'=>$request->Depname,
                'email' => $request->email,
                'tags'=> $request->tags,
                'password' => Hash::make($request->password),
            ]);
                $user->attachRole($request->role_id); 
                event(new Registered($user));

                   $split_comma = explode(",", $request->tags);
                for($i=0;$i<count($split_comma);$i++){
                     $formFields = Activations::create([
                    'Teacher_email' => $split_comma[$i],
                    'Student_email' => $request->email,
                    ]);
                     event(new Registered($formFields));
                }
                return back()->with('message','Student registered successfully!');
            
                }
                else
                {
                    return redirect()->back()->withInput()->with('message',"please fill all teachers on your departments");

            
                }
                
                
            }

         else{
                // dd('sorry you inserted more than one teachers of the same courses');
                return redirect()->back()->withInput()->with('message',"sorry you inserted more than one teachers of the same courses ");

            }
            }
            else{
                // dd('sorry some emails are not registered as teachers');
                return redirect()->back()->withInput()->with('message',"sorry some emails are not registered as teachers");

            }
          
    }






     public function storeadmin(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'Fname' => 'required|string|max:255',
            'Lname' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|confirmed|min:8',
        ]);

        Auth::login($user = User::create([
            'Fname' => $request->Fname,
            'Lname' => $request->Lname,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]));
        $user->attachRole($request->role_id); 
        event(new Registered($user));
       
        return redirect(RouteServiceProvider::HOME);
    }
}
