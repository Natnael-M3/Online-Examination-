<?php

namespace App\Http\Controllers;

use App\Models\Courses;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    //
     public function storecourse(Request $request){
 
         $formFields = $request->validate([
            'dep_name' => 'required',
            'course_name'=>'required|unique:courses,course_name|max:50'
        ]);
        Courses::create($formFields);
        return back()->with('message','Course inserted successfully!');
    }
}
