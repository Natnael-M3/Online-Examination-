<?php

namespace App\Http\Controllers;

use App\Models\Teacher;
use App\Models\Teachers;
use App\Models\Questions;
use App\Models\Activations;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\Registered;

class TeacherController extends Controller
{
    //
     public function store(Request $request,Activations $activate){
    
        // dd($request->all());
            $formFields = $request->validate([
            'chooseQuestion' => 'required',
            'choice1' => 'required',
            'choice2' => 'required',
            'choice3' => 'required',
            'choice4' => 'required',
            'chooseAnswer' => 'required',
            'Teacher_name'=>'required',
            'Teacher_email'=>'required',
        
        ]);
         $affect_dbs = DB::table('activations')
              ->where('Teacher_email', Auth::user()->email)
              ->update(['isActivated' => $request->isActivated]);
    //    dd($formFields);
    $formFields['user_id'] = auth()->id();
    $formFields['Course_Name']= Auth::user()->Coursename;
    $formFields['Dep_Name']= Auth::user()->Depname;
    
    Questions::create($formFields);
    // $num->update($checkActivation);
   
    return redirect('dashboard/postcreate')->with('message','Question inserted Successfully!');
   
 }
 public function examNow(Request $request){
   
    if($request->isActivated == 1){
          $affect_db = DB::table('activations')
              ->where('Teacher_email', Auth::user()->email)
              ->update(['isActivated' => $request->isActivated]);
         return redirect('/dashboard')->with('message','The exam is active now!!');
    }
    else {
         $affect_db = DB::table('activations')
              ->where('Teacher_email', Auth::user()->email)
              ->update(['isActivated' => $request->isActivated]);
         return redirect('/dashboard')->with('message','The exam is not active now!!');
    }
   
    
 }
   public function edit(Request $request){
        //  dd($question_name);
          return view('layouts.edit',[
                   'question_name' =>  last(request()->segments())
                ]);
   }
   public function update(Request $request){
        $array = request()->segments();
         $affect_db_questions = DB::table('questions')
              ->where('chooseQuestion', $array[1])
              ->update([
                'chooseQuestion' => $request->chooseQuestion,
                'choice1'=> $request->choice1,
                'choice2'=> $request->choice2,
                'choice3'=> $request->choice3,
                'choice4'=> $request->choice4,
                'chooseAnswer'=> $request->chooseAnswer,
            ]);
        return redirect('/dashboard/showQuestions')->with('message','Question edited successfully!!');
   }
   public function delete(Request $request){
        
        $question_name = last(request()->segments());
        DB::table('questions')->where('chooseQuestion',$question_name)->delete();
        return redirect('/dashboard/showQuestions')->with('message','Question deleted successfully!!');
   }
   public function edit2(){
     //  dd('hi');
     //  dd(last(request()->segments()));
      return view('layouts.edit2',[
                   'emails' =>  last(request()->segments())
                ]);
   }
 
//update teachers data----------------------------------------------------------------------------------------------
//update teachers data----------------------------------------------------------------------------------------------
   public function update2(Request $request){
                 $array = request()->segments();
           
           if(!empty(DB::table('questions')->select('Teacher_email')->where('Teacher_email',$array[1])->value('Teacher_email'))){
                    $update_db_questions = DB::table('questions')->where('Teacher_email',$array[1])->update([
                         'Teacher_name' => $request->Fname,
                    'Teacher_email' => $request->email
                    ]);
                // $delete_db_teachers = DB::table('teachers')->where('Teacher_email',$array[1])->delete();
          }
          if(!empty(DB::table('teachers')->select('Teacher_email')->where('Teacher_email',$array[1])->value('Teacher_email'))){
                    $update_db_teachers = DB::table('teachers')->where('Teacher_email',$array[1])->update([
                         'Teacher_name' => $request->Fname,
                    'Teacher_email' => $request->email
                    ]);
                // $delete_db_teachers = DB::table('teachers')->where('Teacher_email',$array[1])->delete();
          }
       if(!empty(DB::table('activations')->select('Teacher_email')->where('Teacher_email',$array[1])->value('Teacher_email'))){
                $affect_db_activations = DB::table('activations')->where('Teacher_email',$array[1])->update([
                    'Teacher_email'=> $request->email,
                    'isActivated'=> null,
                ]);
          }
            // dd($array[1]);
            $content = DB::table('users')->select('tags')->where('Coursename',null)->pluck('tags');
          $val = 0;
     
           for($m=1; $m<$content->count(); $m++){
             $concatstring = '';
              $split = explode(',',$content[$m]);
            if(count($split)>1){
                 for($i=0 ; $i<count($split) ; $i++){
                  if($i == count($split)-1){
$concatstring = $concatstring.$split[$i];
                  }
                  else{
                    $concatstring = $concatstring.$split[$i].',';
                  } 
                
            }
            }
            else{
                for($i=0 ; $i<count($split) ; $i++){
               
                $concatstring = $concatstring.$split[$i];
            }
            }
           
            //   dd($split);
            // dd($array[1]);
            for($t=0 ; $t<count($split) ; $t++){

                    if($array[1] == $split[$t]){
                        // dd('hi');
                        $val++;
                        $cindex = $m;
                        $tindex = $t;
                       $concatstring2 = str_replace($split[$t],$request->email,$concatstring);
             
             $affect_db_tags = DB::table('users')->where('tags',$concatstring)->update([
                    'tags'=> $concatstring2
                ]);
                    }
                }

           }
         $affect_db_user = DB::table('users')
              ->where('email', $array[1])
              ->update([
                    'Fname' => $request->Fname,
                    'Lname' => $request->Lname,
                    'email' => $request->email,
                    'password' => Hash::make($request->password), 
            ]);
        
     return redirect('/dashboard')->with('message','Teacher edited successfully!!');
}
   public function delete2(Request $request){
     
  $teacher_email = last(request()->segments());
  // dd($teacher_email);
  $concatstring ='';
  $val = 0;
  $collection = [];
  $student = DB::table('users')->select('email')->where('Coursename',null)->pluck('email');
    // dd($student);
    for($i=1 ; $i< count($student) ; $i++){
        $tag = DB::table('users')->select('tags')->where('email',$student[$i])->value('tags');
        $tags = explode(',',$tag);
        // dd($tags);

        for($j=0; $j < count($tags) ; $j++){
            if($tags[$j] == $teacher_email){
               
               if(count($tags)> 1){
                      for($k=0 ; $k<count($tags ); $k++){
                      if($tags[$k] != $teacher_email){
                             
                             array_push($collection,$tags[$k]);
                      }

                      // $affect_db_tags = DB::table('users')->where('email',$student[$i])->upzz
                }
               }
               if(count($tags) == 1){

                  // dd('delete');
                  $db_tags = DB::table('users')->where('email',$student[$i])->update([
                      'tags' => 'Empty'
                    ]);}
                
              
              
            }
        }
     
                  // dd($collection); 
            
                  if(!empty($collection)){
                      $list = implode(',',$collection);
                      // dd($list);
                    $affect_db_tags = DB::table('users')->where('email',$student[$i])->update([
                      'tags' => $list
                    ]);

                  }
                 
             
              $collection = [];

    }

  //     dd($concatstring);
  //  dd($val);
//  dd($tags);
    
    if(!empty(DB::table('questions')->select('Teacher_email')->where('Teacher_email',$teacher_email)->value('Teacher_email'))){
      DB::table('questions')->where('Teacher_email',$teacher_email)->delete();
    }
    if(!empty(DB::table('activations')->select('Teacher_email')->where('Teacher_email',$teacher_email)->value('Teacher_email'))){
          DB::table('activations')->where('Teacher_email',$teacher_email)->delete();
    }
   if(!empty(DB::table('teachers')->select('Teacher_email')->where('Teacher_email',$teacher_email)->value('Teacher_email'))){
          DB::table('teachers')->where('Teacher_email',$teacher_email)->delete();
    }
    DB::table('users')->where('email',$teacher_email)->delete();
        return redirect('/dashboard')->with('message','Teacher deleted successfully!!');
}
//update students data--------------------------------------------------------------------------------------
//update students data--------------------------------------------------------------------------------------
   public function update3(Request $request){

  $arrays = DB::table('users')->select('stud_id')->pluck('stud_id');
               $array = request()->segments();
              //  dd($array);
                $val = 0;
                for($k=0 ; $k < count($arrays) ; $k++){
                    if($request->stud_id != null){
                        if($arrays[$k]== $request->stud_id){
                        $val = $val + 1;
                        $stud_id = $arrays[$k];
                        }
                    }
                }
                DB::table('users')->select('stud_id')
                     ->where('email', $array[1])->value('stud_id');
               if( DB::table('users')->select('stud_id')
                     ->where('email', $array[1])->value('stud_id') == $stud_id){
                    $val = 0;
               }

                if($val == 1){
                    return redirect()->back()->withInput()->with('message',"the stud_id must be unique");
                }
              if($val == 0){
                //  dd($request->all());
                   $affect_db_user =  DB::table('users')
                     ->where('email', $array[1])->update([
                    'email'=> $request->email,
                    'Fname'=> $request->Fname,
                    'Lname'=> $request->Lname,
                    'stud_id'=> $request->stud_id,
                    'password' => Hash::make($request->password),
                     ]);
              
                    if(!empty(DB::table('activations')->select('Student_email')->where('Student_email',$array[1])->value('Student_email'))){
                         $affect_db_activations = DB::table('activations')
                     ->where('Student_email', $array[1])->update([
                    'Student_email'=> $request->email,
                     ]);
                    }
                    if(!empty(DB::table('teachers')->select('Student_email')->where('Student_email',$array[1])->value('Student_email'))){
                    $affect_db_teachers = DB::table('teachers')
                     ->where('Student_email', $array[1])->update([
                    'Student_email'=> $request->email,
                    'Student_Fname'=> $request->Fname,
                    'Student_Lname'=> $request->Lname,
                    'Student_id'=> $request->stud_id,
                     ]);
                    }
                    
                         return redirect('/dashboard')->with('message','User edited successfully!!');
                  }
     
   }
  public function delete3(Request $request){
     // dd('hi');
  $student_email = last(request()->segments());
//   dd($student_email);
    if(!empty(DB::table('activations')->select('Student_email')->where('Student_email',$student_email)->value('Student_email'))){
          DB::table('activations')->where('Student_email',$student_email)->delete();
    }
   if(!empty(DB::table('teachers')->select('Student_email')->where('Student_email',$student_email)->value('Student_email'))){
          DB::table('teachers')->where('Student_email',$student_email)->delete();
    }
    DB::table('users')->where('email',$student_email)->delete();
        return redirect('/dashboard')->with('message','Student deleted successfully!!');
}

}
