<?php

namespace App\Http\Controllers;

use App\Models\Questions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class DashboardController extends Controller
{
   public function index(Request $request)
   {
      
       if(Auth::user()->hasRole('user')){
         
            return view('userdash',[
            'questions'=> Questions::latest()->get(),
            
            ]);
       }elseif(Auth::user()->hasRole('blogwriter')){
            return view('blogwriterdash');
       }elseif(Auth::user()->hasRole('admin')){
      return view('dashboard');
     
   }
   }

   public function myprofile()
   {
    return view('myprofile');
   }

   public function postcreate()
   {
    
    return view('postcreate');
   }
}
