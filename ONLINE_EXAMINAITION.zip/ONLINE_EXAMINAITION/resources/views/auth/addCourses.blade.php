<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Courses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
</head>

<body class="h-screen  bg-no-repeat bg-cover"
    style="background-image: url('https://i.pinimg.com/564x/19/9f/d2/199fd29184c6cff24e3445f849af463e.jpg')">
    <div class=" flex flex-col h-full">
        <div>
            <a href="/dashboard" class=" ml-3 text-white"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

        </div>
        <div class=" flex flex-col justify-center items-center h-full">
            <div class="w-4/5 md:w-1/3  mt-6 px-6  md:py-8 py-16 bg-white shadow-md overflow-hidden rounded-lg">
                <x-auth-validation-errors class="mb-4" :errors="$errors" />
                @if (DB::table('departments')->select('dep_name')->get()->isEmpty() == 1)
                    <div class="flex flex-row justify-center">
                        <p class="mt-6">You should add at least one departments</p>
                    </div>
                    <div class="flex flex-row justify-end mt-4	">
                        <a href="/dashboard/addDepartments"
                            class="ml-20 p-2 mt-12 border-white text-white border-2 bg-violet-500 hover:bg-violet-600 active:bg-violet-800 rounded-lg">Add
                            Departments</a>
                    </div>
                    {{-- <span>empty departments </span><span><a href="/addDepartments"
                            class="text-sky-400 p-2 border-2 border-cyan-500">Add departments</a></span> --}}
                @else
                    <form method="POST" action="/add/courses">
                        @csrf
                        <!-- Departments -->
                        <x-label for="Depname" :value="'Department'" />
                        <select name="dep_name" id="Depname"
                            class='block bg-white w-full border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm'>
                            <option value="" disabled='disabled' selected='selected'>Choose Departments</option>
                            @foreach (DB::table('departments')->select('dep_name')->pluck('dep_name') as $depname)
                                <option value="{{ $depname }}" name="dep_name" class="depc">
                                    <x-label>{{ $depname }}</x-label>
                                </option>
                            @endforeach

                        </select>
                        <!-- Courses -->
                        <div>
                            <x-label for="Fname" :value="'Add Courses'" />

                            <x-input id="Fname" class="block mt-1 w-full" type="text" name="course_name"
                                :value="old('course_name')" required autofocus />
                        </div>

                        <div class="flex flex-row justify-end mt-2">
                            {{-- <x-button class="ml-4">
                            {{ 'Add Courses' }}
                        </x-button> --}}
                            <button class="mt-6 w-1/3 p-1.5  rounded-md	 bg-cyan-700 text-white hover:bg-cyan-600	">
                                Add Courses
                            </button>
                        </div>
                    </form>
                @endif

            </div>

            </form>
        </div>
    </div>

    {{-- <x-auth-card>
    </x-auth-card> --}}
    <x-notify_message />
</body>

</html>
