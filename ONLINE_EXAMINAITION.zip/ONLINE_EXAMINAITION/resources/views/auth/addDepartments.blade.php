<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Departments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
</head>

<body class="h-screen  bg-no-repeat bg-cover"
    style="background-image: url('https://i.pinimg.com/564x/19/9f/d2/199fd29184c6cff24e3445f849af463e.jpg')">


    <div class=" flex flex-col h-full">
        <div>
            <a href="/dashboard" class=" ml-3 text-white"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

        </div>
        <div class=" flex flex-col justify-center items-center h-full">
            <div class="w-4/5 md:w-1/3  mt-6 px-6  md:py-8 py-16 bg-white shadow-md overflow-hidden rounded-lg">
                <x-auth-validation-errors class="mb-4" :errors="$errors" />
                <form method="POST" action="/add/departments">
                    @csrf

                    <!-- Departments -->
                    <div>
                        <x-label for="Fname" :value="'Add Departments'" />
                        <x-input id="Fname" class="block mt-1 w-full" type="text" name="dep_name"
                            :value="old('dep_name')" required autofocus />
                    </div>
                    <div class="flex flex-row justify-end	">
                        <button class="mt-6 w-1/3 p-1.5  rounded-md	 bg-cyan-700 text-white hover:bg-cyan-600	">
                            Add Department
                        </button>
                    </div>

            </div>

            </form>
        </div>
    </div>
    <x-notify_message />
</body>

</html>
