<x-guest-layout>
    <div class="flex flex-col  h-screen   gap-0 pt-6 sm:pt-0 bg-gray-100 bg-no-repeat bg-cover">
        <div class="w-full h-1/5 mt-0  flex flex-col	">
            <div class="w-2/5 h-full  bg-green-400	">

            </div>
            <div class="w-3/5">

            </div>
        </div>
        <div class="flex flex-row h-full w-full ml-0 mr-0  ">
            <div class="w-1/5  bg-green-400">

            </div>
            <div class="h-full w-3/5  flex flex-row shadow-2xl shadow-slate-900	">
                <div class="h-full w-1/4 bg-green-400 text-white flex text-2xl justify-end items-center ">
                    Login
                </div>
                <div class="h-full w-1/4 bg-green-400	">

                </div>
                <div class="h-full w-full bg-white flex items-center ">
                    <div
                        class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg ml-10">

                        <!-- Session Status -->
                        <x-auth-session-status class="mb-4" :status="session('status')" />

                        <!-- Validation Errors -->
                        <x-auth-validation-errors class="mb-4" :errors="$errors" />

                        <form method="POST" action="{{ route('login') }}">
                            @csrf

                            <!-- Email Address -->
                            <div>
                                <x-label for="email" :value="__('Email')" />

                                <x-input id="email" class="block mt-1 w-full" type="email" name="email"
                                    :value="old('email')" required autofocus />
                            </div>

                            <!-- Password -->
                            <div class="mt-4">
                                <x-label for="password" :value="__('Password')" />

                                <x-input id="password" class="block mt-1 w-full" type="password" name="password"
                                    required autocomplete="current-password" />
                            </div>

                            <!-- Remember Me -->
                            {{-- <div class="block mt-4">
                                <label for="remember_me" class="inline-flex items-center">
                                    <input id="remember_me" type="checkbox"
                                        class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                        name="remember">
                                    <span class="ml-2 text-sm text-gray-600">{{ __('Remember me') }}</span>
                                </label>
                            </div> --}}

                            <div class="flex items-center justify-end mt-4">
                                {{-- @if (Route::has('password.request'))
                                    <a class="underline text-sm text-gray-600 hover:text-gray-900"
                                        href="{{ route('password.request') }}">
                                        {{ __('Forgot your password?') }}
                                    </a>
                                @endif --}}

                                {{-- <x-button class="ml-3 ">
                                    {{ __('Login') }}
                                </x-button> --}}
                                {{-- <button type="submit"
                                    class="ml-3 inline-flex items-center px-4 py-2 bg-sky-900	 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-sky-700		 active:bg-sky-700 focus:outline-none focus:bg-sky-700 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                                    {{ __('Login') }}

                                </button> --}}
                                <button type="submit"
                                    class="ml-3 p-2 w-40	 rounded-md	 border-2 border-blue-500 bg-blue-500 text-white hover:text-black hover:bg-white">
                                    Login
                                </button>
                            </div>
                        </form>

                    </div>

                </div>
            </div>

        </div>
        <div class="w-full h-1/5	">
            <div class="w-2/5 h-full bg-green-400">

            </div>
            <div class="w-3/5">

            </div>
        </div>
    </div>
</x-guest-layout>
