<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register Student</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
    <style>
        @media(max-width:767px) {
            .toshow {
                display: none;
            }

            .backicon {
                display: block;
            }
        }

        @media(min-width:768px) {
            .backicon {
                display: none
            }
        }
    </style>
</head>

<body class="md:overflow-y-hidden  bg-gray-100">

    <a href="/dashboard" class="backicon ml-3 text-black"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

    <div class="min-h-screen flex flex-col items-center justify-center md:flex-row sm:pt-0 bg-gray-100">

        <div class="toshow md:visible md:w-1/2   h-screen  ml-1/2 md:overflow-y-scroll max-h-screen bg-slate-200	">
            <a href="/dashboard" class=" md:ml-3 md:text-black"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

            @if (DB::table('departments')->select('dep_name')->count() > 0 &&
                DB::table('courses')->select('course_name')->count() > 0)
                <div class="w-4/5  m-auto flex justify-center">
                    <table class="  mt-4 table-auto">
                        <tr>
                            <th class="border-2 border-zinc-600  px-2 bg-zinc-600 text-white  hover:bg-slate-800  ">
                                first_name</th>
                            <th class="border-2 border-zinc-600 px-2 py-1 bg-zinc-600 text-white  hover:bg-slate-800  ">
                                last_name</th>
                            <th class="border-2 border-zinc-600 px-3 py-1 bg-zinc-600 text-white  hover:bg-slate-800  ">
                                email</th>
                            <th class="border-2 border-zinc-600 px-2 py-1 bg-zinc-600 text-white  hover:bg-slate-800  ">
                                dep_name</th>
                            <th class="border-2 border-zinc-600 px-2 py-1 bg-zinc-600 text-white  hover:bg-slate-800  ">
                                course_name</th>

                        </tr>
                        @for ($i = 1;
    $i <
    DB::table('users')->select('Fname')->where('tags', null)->count();
    $i++)
                            <tr>
                                <td class="border-2 pl-2 py-1.5 border-zinc-600">
                                    {{ DB::table('users')->select('Fname')->where('tags', null)->pluck('Fname')->get($i) }}
                                </td>
                                <td class="border-2 px-2 py-1.5 border-zinc-600">
                                    {{ DB::table('users')->select('Lname')->where('tags', null)->pluck('Lname')->get($i) }}
                                </td>
                                <td class="border-2 px-3 py-1.5 border-zinc-600">
                                    {{ DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i) }}
                                </td>
                                <td class="border-2 px-2 py-1.5 border-zinc-600">
                                    {{ DB::table('users')->select('Depname')->where('tags', null)->pluck('Depname')->get($i) }}
                                </td>
                                <td class="border-2 px-2 py-1.5 border-zinc-600">
                                    {{ DB::table('users')->select('Coursename')->where('tags', null)->pluck('Coursename')->get($i) }}
                                </td>
                            </tr>
                        @endfor

                    </table>
                </div>

            @endif

        </div>
        <!------------------------------------------------------------------------------------------------------>
        <div
            class="  w-4/5 h-full md:w-1/2 flex flex-row justify-center ml-1/2 md:overflow-y-scroll md:h-screen md:bg-slate-900">
            <div class="w-full h-full  sm:max-w-md mt-2 px-6 py-2  bg-white shadow-md  sm:rounded-lg">


                <x-auth-validation-errors class="mb-4" :errors="$errors" />

                @if (DB::table('departments')->select('dep_name')->get()->isEmpty() == 1)
                    <div class="flex flex-col h-full gap-2 justify-center sm:border-2 sm:border-yellow-600">
                        <div class="flex flex-row justify-center">
                            <p>You should add at least one teachers</p>
                        </div>
                        <div class="flex flex-row justify-center">
                            <a href="/dashboard/addDepartments"
                                class="p-1.5 w-40 flex  border-white border-2 bg-violet-500 hover:bg-violet-600 active:bg-violet-800 rounded-lg">Add
                                Departments
                            </a>
                        </div>
                    </div>
                @elseif (DB::table('courses')->select('course_name')->get()->isEmpty() == 1)
                    <div class="flex flex-col h-full gap-2 justify-center border-2 border-yellow-600">
                        <div class="flex flex-row justify-center">
                            <p>You should add at least one teachers</p>
                        </div>
                        <div class="flex flex-row justify-center">
                            <a href="/dashboard/addCourses"
                                class="p-1.5 w-1/3 border-white border-2 bg-violet-500 hover:bg-violet-600 active:bg-violet-800 rounded-lg">Add
                                Courses
                            </a>
                        </div>
                    </div>
                @elseif (DB::table('users')->select('tags')->where('tags', null)->count() < 2)
                    <div class="flex flex-col h-full gap-2 justify-center border-2 border-yellow-600">
                        <div class="flex flex-row justify-center">
                            <p>You should add at least one teachers</p>
                        </div>
                        <div class="flex flex-row justify-center">
                            <a href="/dashboard/registerteacher"
                                class="p-1.5 w-1/3 border-white border-2 bg-violet-500 hover:bg-violet-600 active:bg-violet-800 rounded-lg">Register
                                Teacher
                            </a>
                        </div>
                    </div>
                @else
                    <form method="POST" action="/register/student" enctype="multipart/form-data">
                        @csrf

                        <!-- Name -->
                        <div>
                            <x-label for="Fname" :value="'First Name'" />

                            <x-input id="Fname" class="block mt-0.5 w-full" type="text" name="Fname"
                                :value="old('Fname')" required autofocus />
                        </div>
                        <div>
                            <x-label for="Lname" :value="'Last Name'" />

                            <x-input id="Lname" class="block mt-0.5 w-full" type="text" name="Lname"
                                :value="old('Lname')" required autofocus />
                        </div>
                        <!-- Student id --->
                        <div>
                            <x-label for="stud_id" :value="'Student Id'" />

                            <x-input id="stud_id" class="block mt-0.5 w-full" type="text" name="stud_id"
                                :value="old('stud_id')" required autofocus />
                        </div>
                        <!-- Email Address -->
                        <div class="mt-4">
                            <x-label for="email" :value="__('Email')" />

                            <x-input id="email" class="block mt-0.5 w-full" type="email" name="email"
                                :value="old('email')" required />
                        </div>

                        <!-- Password -->
                        <div class="mt-4">
                            <x-label for="password" :value="__('Password')" />

                            <x-input id="password" class="block mt-0.5 w-full" type="password" name="password" required
                                autocomplete="new-password" />
                        </div>

                        <!-- Confirm Password -->
                        <div class="mt-4">
                            <x-label for="password_confirmation" :value="__('Confirm Password')" />

                            <x-input id="password_confirmation" class="block mt-0.5 w-full" type="password"
                                name="password_confirmation" required />
                        </div>
                        <!-- Department Name -->

                        <div>
                            <x-label for="Depname" :value="'Department'" />
                            <select name="Depname" id="Depname"
                                class="block bg-white w-full border border-slate-300 rounded-md py-1 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm">
                                <option value="" disabled='disabled' selected='selected'>Choose Departments
                                </option>
                                @foreach (DB::table('departments')->select('dep_name')->pluck('dep_name') as $depname)
                                    <option value="{{ $depname }}">{{ $depname }}</option>
                                @endforeach

                            </select>
                        </div>
                        <!-- Teacher adding using comma -->
                        <div class="mt-3">
                            <x-label for="addteachers" :value="'Teachers for student ( Comma Separated Email )'" />
                            <x-input id="tags" class="block mt-0.5 w-full" type="text" name="tags"
                                :value="old('tags')" placeholder="Example: hibst@gmail.com,alemu@hotmail.com etc"
                                required />

                        </div>
                        <!-- Select Option Rol type -->
                        <div class="mt-4" hidden>
                            <x-label for="role_id" value="{{ __('Register as:') }}" />
                            <select name="role_id"
                                class="block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
                                <option value="user">Student</option>
                            </select>
                        </div>
                        <div class="flex flex-row justify-center items-center mt-4">

                            <button class=" w-3/5 p-1.5 rounded-md	 bg-cyan-700 text-white hover:bg-cyan-600	">
                                Register
                            </button>
                        </div>

                        {{-- <div class="flex items-center justify-end mt-3">
                            <x-button id="register" class="ml-4">
                                {{ 'Register' }}
                            </x-button>
                        </div> --}}
                    </form>
                @endif

            </div>


        </div>
    </div>
    {{-- <x-auth-card>
      
       
    </x-auth-card> --}}
    <x-notify_message2 />
</body>

</html>

{{-- <x-guest-layout>

</x-guest-layout> --}}
