<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Online Examination</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <!-- Styles -->
    {{-- <style>
        /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
        html {
            line-height: 1.15;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        a {
            background-color: transparent
        }

        [hidden] {
            display: none
        }

        html {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            line-height: 1.5
        }

        *,
        :after,
        :before {
            box-sizing: border-box;
            border: 0 solid #e2e8f0
        }

        a {
            color: inherit;
            text-decoration: inherit
        }

        svg,
        video {
            display: block;
            vertical-align: middle
        }

        video {
            max-width: 100%;
            height: auto
        }

        .bg-white {
            --bg-opacity: 1;
            background-color: #fff;
            background-color: rgba(255, 255, 255, var(--bg-opacity))
        }

        .bg-gray-100 {
            --bg-opacity: 1;
            background-color: #f7fafc;
            background-color: rgba(247, 250, 252, var(--bg-opacity))
        }

        .border-gray-200 {
            --border-opacity: 1;
            border-color: #edf2f7;
            border-color: rgba(237, 242, 247, var(--border-opacity))
        }

        .border-t {
            border-top-width: 1px
        }

        .flex {
            display: flex
        }

        .grid {
            display: grid
        }

        .hidden {
            display: none
        }

        .items-center {
            align-items: center
        }

        .justify-center {
            justify-content: center
        }

        .font-semibold {
            font-weight: 600
        }

        .h-5 {
            height: 1.25rem
        }

        .h-8 {
            height: 2rem
        }

        .h-16 {
            height: 4rem
        }

        .text-sm {
            font-size: .875rem
        }

        .text-lg {
            font-size: 1.125rem
        }

        .leading-7 {
            line-height: 1.75rem
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto
        }

        .ml-1 {
            margin-left: .25rem
        }

        .mt-2 {
            margin-top: .5rem
        }

        .mr-2 {
            margin-right: .5rem
        }

        .ml-2 {
            margin-left: .5rem
        }

        .mt-4 {
            margin-top: 1rem
        }

        .ml-4 {
            margin-left: 1rem
        }

        .mt-8 {
            margin-top: 2rem
        }

        .ml-12 {
            margin-left: 3rem
        }

        .-mt-px {
            margin-top: -1px
        }

        .max-w-6xl {
            max-width: 72rem
        }

        .min-h-screen {
            min-height: 100vh
        }

        .overflow-hidden {
            overflow: hidden
        }

        .p-6 {
            padding: 1.5rem
        }

        .py-4 {
            padding-top: 1rem;
            padding-bottom: 1rem
        }

        .px-6 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }

        .pt-8 {
            padding-top: 2rem
        }

        .fixed {
            position: fixed
        }

        .relative {
            position: relative
        }

        .top-0 {
            top: 0
        }

        .right-0 {
            right: 0
        }

        .shadow {
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px 0 rgba(0, 0, 0, .06)
        }

        .text-center {
            text-align: center
        }

        .text-gray-200 {
            --text-opacity: 1;
            color: #edf2f7;
            color: rgba(237, 242, 247, var(--text-opacity))
        }

        .text-gray-300 {
            --text-opacity: 1;
            color: #e2e8f0;
            color: rgba(226, 232, 240, var(--text-opacity))
        }

        .text-gray-400 {
            --text-opacity: 1;
            color: #cbd5e0;
            color: rgba(203, 213, 224, var(--text-opacity))
        }

        .text-gray-500 {
            --text-opacity: 1;
            color: #a0aec0;
            color: rgba(160, 174, 192, var(--text-opacity))
        }

        .text-gray-600 {
            --text-opacity: 1;
            color: #718096;
            color: rgba(113, 128, 150, var(--text-opacity))
        }

        .text-gray-700 {
            --text-opacity: 1;
            color: #4a5568;
            color: rgba(74, 85, 104, var(--text-opacity))
        }

        .text-gray-900 {
            --text-opacity: 1;
            color: #1a202c;
            color: rgba(26, 32, 44, var(--text-opacity))
        }

        .underline {
            text-decoration: underline
        }

        .antialiased {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .w-5 {
            width: 1.25rem
        }

        .w-8 {
            width: 2rem
        }

        .w-auto {
            width: auto
        }

        .grid-cols-1 {
            grid-template-columns: repeat(1, minmax(0, 1fr))
        }

        @media (min-width:640px) {
            .sm\:rounded-lg {
                border-radius: .5rem
            }

            .sm\:block {
                display: block
            }

            .sm\:items-center {
                align-items: center
            }

            .sm\:justify-start {
                justify-content: flex-start
            }

            .sm\:justify-between {
                justify-content: space-between
            }

            .sm\:h-20 {
                height: 5rem
            }

            .sm\:ml-0 {
                margin-left: 0
            }

            .sm\:px-6 {
                padding-left: 1.5rem;
                padding-right: 1.5rem
            }

            .sm\:pt-0 {
                padding-top: 0
            }

            .sm\:text-left {
                text-align: left
            }

            .sm\:text-right {
                text-align: right
            }
        }

        @media (min-width:768px) {
            .md\:border-t-0 {
                border-top-width: 0
            }

            .md\:border-l {
                border-left-width: 1px
            }

            .md\:grid-cols-2 {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }
        }

        @media (min-width:1024px) {
            .lg\:px-8 {
                padding-left: 2rem;
                padding-right: 2rem
            }
        }

        @media (prefers-color-scheme:dark) {
            .dark\:bg-gray-800 {
                --bg-opacity: 1;
                background-color: #2d3748;
                background-color: rgba(45, 55, 72, var(--bg-opacity))
            }

            .dark\:bg-gray-900 {
                --bg-opacity: 1;
                background-color: #1a202c;
                background-color: rgba(26, 32, 44, var(--bg-opacity))
            }

            .dark\:border-gray-700 {
                --border-opacity: 1;
                border-color: #4a5568;
                border-color: rgba(74, 85, 104, var(--border-opacity))
            }

            .dark\:text-white {
                --text-opacity: 1;
                color: #fff;
                color: rgba(255, 255, 255, var(--text-opacity))
            }

            .dark\:text-gray-400 {
                --text-opacity: 1;
                color: #cbd5e0;
                color: rgba(203, 213, 224, var(--text-opacity))
            }
        }
    </style> --}}

    <style>
        body {
            font-family: 'Nunito';
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        .heights {
            height: 85vh;
            overflow: hidden;
        }


        .heights3 {
            height: 500px;
        }

        @media (min-width: 760px) {
            .formedia {
                display: flex;
                flex-direction: row;
                height: 75%;
            }

            .textmedia {
                width: 40%;
                /* border: 2px solid black; */
                overflow: hidden;
            }

            .imagemedia {
                /* w-3/5 border-2 border-slate-300; */
                width: 60%;

            }

            .heights2 {
                height: 250vh
            }

            .imagenav1 {
                /* flex flex-row w-full gap-4 mt-0 justify-center h-20 py-2.5 fixed hidden  */
                display: flex;
                flex-direction: row;
                justify-content: center;
                width: 100%;
                gap: 1rem;
                height: 5rem;
                padding-top: 0.625rem;
                position: fixed;
            }

            .imagenav2 {
                /* flex flex-row w-full gap-4 mt-0 justify-center  */
                display: flex;
                flex-direction: row;
                justify-content: center: width: 100%;
                gap: 1rem;
                margin-top: 0;
            }


        }

        @media (max-width:759px) {
            .formedia {
                display: flex;
                flex-direction: column;
                width: 100%;
            }

            .textmedia {
                width: 90%;
                margin: 15px;
            }

            .imagemedia {
                height: 400px;
            }

            .heights2 {
                height: 400vh;
            }

            .imagenav1 {
                /* flex flex-row w-full gap-4 mt-0 justify-center h-20 py-2.5 fixed hidden  */
                display: flex;
                flex-direction: row;
                justify-content: center;
                width: 100%;
                gap: 1rem;
                height: 5rem;
                position: fixed;
                /* border: 3px solid red; */
            }

            .titles {
                margin-top: 5rem;
                width: 100%;
            }

            .imagenav2 {
                /* flex flex-row w-full gap-4 mt-0 justify-center  */
                display: none;
                visibility: hidden;

            }



        }
    </style>
</head>

<body class="antialiased">

    <div class="flex flex-col" id="main">
        @if (Route::has('login'))
            @auth
                @php
                    header('Location: ' . URL::to('/dashboard'), true, 302);
                    exit();
                @endphp
                {{-- <a href="{{ url('/dashboard') }}" class="text-sm text-gray-700 underline">Dashboard</a> --}}
            @else
                <div id="nav1" class=" bg-zinc-600 hidden imagenav1">
                    <a href="{{ route('login') }} " style="margin-top:20px;color:white" class="text-lg h-4 "
                        id="">Login</a>
                    @if (Route::has('registeradmin'))
                        {{-- <a href="{{ route('registeradmin') }}">Register for
                            Admin</a> --}}
                    @endif
                    <a href="/about" style="margin-top: 20px;color:white"class="text-lg h-4 ">About
                        us</a>
                    <a href="/contact" style="margin-top: 20px;color:white "class="text-lg h-4">Contact us</a>
                    <button class="hidden"><i class="fa fa-bars" aria-hidden="true"></i></button>
                </div>
                <div class=" heights bg-cover bg-no-repeat imagenav2" id="nav2"
                    style="background-image: url('https://i0.wp.com/onlineexamhelp.eklavvya.in/wp-content/uploads/2021/05/New-blogs-2.png?fit=1500%2C900&ssl=1')">
                    <div id="nav2" class="flex flex-row w-full gap-4 mt-0 justify-center dyes">
                        <a href="{{ route('login') }} " style="margin-top:20px;color:white"
                            class="text-xl h-4 underline underline-offset-4 decoration-orange-500">Login</a>
                        @if (Route::has('registeradmin'))
                            {{-- <a href="{{ route('registeradmin') }}" style="margin-top:20px;color:white"
                                class="text-xl h-4 underline underline-offset-4 decoration-orange-500">Register for
                                Admin</a> --}}
                        @endif
                        <a href="/about" style="margin-top: 20px;color:white " class="text-xl h-4">A<u
                                class="text-xl underline underline-offset-4 decoration-orange-500 ">bout u</u>s</a>
                        <a href="/contact" style="margin-top: 20px;color:white " class="text-xl h-4">C<u
                                class="text-xl underline underline-offset-4 decoration-orange-500 ">ontact u</u>s</a>
                    </div>

                @endauth
            </div>


        @endif
        <div class="flex justify-center items-center h-16 bg-slate-300 titles">
            <p class="underline decoration-sky-700 decoration-2 underline-offset-4 text-black">Main feature of this
                website
            </p>
        </div>
        <div class="flex flex-col overflow-hidden heights2">
            <div class="formedia">
                <div class="textmedia">
                    <div class="flex flex-col shadow-lg shadow-slate-500 rounded-lg mt-8 ml-16 mr-16 mt-32 p-4 ">
                        <h1 class=" mt-4 text-xl font-semibold text-blue-800 font-sans flex flex-col items-center">Admin
                        </h1>
                        <p class="ml-8	mr-8 mt-4 mb-2 font-sans text-blue-800 ">
                            The the administrator can register departments,register courses, register teachers with
                            their
                            department and assingned courses,register students with their assingned departments and
                            course teachers
                        </p>

                    </div>
                </div>
                <div class="imagemedia">
                    <div class="h-5/6 rounded-lg shadow-lg shadow-slate-500 m-8 bg-cover bg-no-repeat "
                        style="background-image: url('https://www.betterteam.com/images/administrative-manager-job-description-4076x2712-2020124.jpeg?crop=40:21,smart&width=1200&dpr=2')">

                    </div>
                </div>
            </div>
            <div class="formedia ">
                <div class="imagemedia">
                    <div class="h-5/6 rounded-lg shadow-lg shadow-slate-500 m-8 bg-cover bg-no-repeat"
                        style="background-image: url('https://images.squarespace-cdn.com/content/v1/5914d249d2b857304e916f1d/1494542184647-BXY0FTDJO3C8P7ZR1GUJ/image-asset.jpeg?format=1000w')">

                    </div>
                </div>
                <div class="textmedia">
                    <div class="flex flex-col shadow-lg shadow-slate-500 rounded-lg mt-8 ml-16 mr-16 mt-32 p-4 ">
                        <h1 class=" mt-4 text-xl font-semibold text-blue-800 font-sans flex flex-col items-center">
                            Teachers
                        </h1>
                        <p class="ml-8	mr-8 mt-4 mb-2 font-sans text-blue-800 ">
                            Registerd teachers can add questions, edit and delete questions and also can show the recent
                            results of it's asssinged students
                        </p>

                    </div>
                </div>

            </div>
            <div class="formedia">
                <div class="textmedia">
                    <div class="flex flex-col shadow-lg shadow-slate-500 rounded-lg mt-8 ml-16 mr-16 mt-32 p-4 ">
                        <h1 class=" mt-4 text-xl font-semibold text-blue-800 font-sans flex flex-col items-center">
                            Students
                        </h1>
                        <p class="ml-8	mr-8 mt-4 mb-2 font-sans text-blue-800 ">
                            Registered students can take their exams based on thier registered departments and
                            registered teachers on their departements and also show
                            their results

                        </p>


                    </div>
                </div>
                <div class="imagemedia">
                    <div class="h-5/6 rounded-lg shadow-lg shadow-slate-500 m-8 bg-cover bg-no-repeat"
                        style="background-image: url('https://i0.wp.com/www.currentschoolnews.com/wp-content/uploads/2020/02/ETHIOPIA.png?fit=1024%2C683&ssl=1')">

                    </div>
                </div>
            </div>

        </div>

    </div>
    <footer class="h-56	bg-slate-800 flex flex-col items-center gap-4">
        <p class="text-white mt-16"><i class="fa fa-envelope" aria-hidden="true"></i><a
                href="mailto:natmebratu@gmail.com"><span class="text-white ml-2">natmebratu@gmail.com</span></a></p>

        <p class="text-white"><i class="fab fa-telegram" aria-hidden="true"></i><a
                href="https://t.me/Nati_Mebratu"><span class="text-white ml-2">https://t.me/Nati_Mebratu</span>
            </a>

        </p>



    </footer>
    <script>
        window.addEventListener('scroll', () => {
            const scrolled = window.scrollY;
            // console.log(scrolled);

            // console.log(window.innerWidth);
            if (scrolled > 500 && window.innerWidth > 759) {
                document.getElementById('nav1').classList.remove('hidden');

            }

            if (scrolled < 501 && window.innerWidth > 759) {
                document.getElementById('nav1').classList.add('hidden');
            }

        })
        window.addEventListener('resize', function(event) {
            if (window.innerWidth < 760) {
                document.getElementById('nav1').classList.remove('hidden');
            }
        });
    </script>
</body>

</html>
