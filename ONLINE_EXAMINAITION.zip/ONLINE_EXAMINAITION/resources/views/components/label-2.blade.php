@props(['value'])

<label {{ $attributes->merge(['class' => 'block font-medium text-sm text-zinc-200 italic mt-2']) }}>
    {{ $value ?? $slot }}
</label>
