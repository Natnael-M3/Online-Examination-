{{-- @props(['title']) --}}
<div>
   <a  href="/maths" >{{$title}}</a><br><br>
</div>