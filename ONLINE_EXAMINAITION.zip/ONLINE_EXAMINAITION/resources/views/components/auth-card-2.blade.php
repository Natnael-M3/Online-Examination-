<div class="flex flex-col items-center mt-0 ">
    <div class="w-4/5 md:w-2/6  bg-slate-700  sm:max-w-md  px-6 py-4 shadow-md overflow-hidden sm:rounded-lg">
        {{ $slot }}
    </div>
</div>
