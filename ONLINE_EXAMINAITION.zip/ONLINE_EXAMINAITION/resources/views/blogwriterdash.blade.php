<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard for Teacher') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">


            <div>
                {{-- {{ $course_name = DB::table('users')->select('Coursename')->where('email', Auth::user()->email)->value('Coursename') }} --}}

                @if (DB::table('activations')->select('Student_email')->where('Teacher_email', Auth::user()->email)->count() > 0)
                    <table class="flex justify-center">
                        <tr>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student first_name</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student last_name</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student id</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Student email</th>
                            <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                                Result
                            </th>
                        </tr>

                        @foreach (DB::table('activations')->select('Student_email')->where('Teacher_email', Auth::user()->email)->pluck('Student_email') as $teacher_students)
                            <tr>
                                <td class="border-2 px-5 py-2 border-slate-700">
                                    {{ DB::table('users')->select('Fname')->where('email', $teacher_students)->value('Fname') }}
                                </td>
                                <td class="border-2 px-5 py-2 border-slate-700">
                                    {{ DB::table('users')->select('Lname')->where('email', $teacher_students)->value('Lname') }}
                                </td>
                                <td class="border-2 px-5 py-2 border-slate-700">

                                    {{ DB::table('users')->select('stud_id')->where('email', $teacher_students)->value('stud_id') }}
                                </td>
                                <td class="border-2 px-5 py-2 border-slate-700">

                                    {{ DB::table('users')->select('email')->where('email', $teacher_students)->value('email') }}
                                </td>
                                @if (DB::table('teachers')->select('result')->where('Student_email', $teacher_students)->where(
                                        'Course_name',
                                        DB::table('users')->select('Coursename')->where('email', Auth::user()->email)->value('Coursename'))->count() > 0)
                                    <td class="border-2 px-5 py-2 border-slate-700">
                                        {{ DB::table('teachers')->select('result')->where('Student_email', $teacher_students)->where('Course_name',DB::table('users')->select('Coursename')->where('email', Auth::user()->email)->value('Coursename'))->value('result') }}
                                    </td>
                                @else
                                    <td class="border-2 px-5 py-2 border-slate-700">
                                        0
                                    </td>
                                @endif
                            </tr>
                        @endforeach


                    </table>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
