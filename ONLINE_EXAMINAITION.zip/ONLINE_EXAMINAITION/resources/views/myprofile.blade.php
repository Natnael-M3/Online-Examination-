<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard for user') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="flex flex-row justify-center mb-10">
            <h1 class="font-serif text-xl">Your results are below</h1>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            {{-- <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in as a user! <br>
                    Your name is: {{Auth::user()->Fname}} <br>
                    Your email addrress: {{Auth::user()->email}}
                 
                </div> --}}
            {{-- {{ DB::table('teachers')->select('result')->count() }} --}}

            <table class="flex justify-center">
                <tr>
                    @foreach (DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name') as $courses)
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            {{ $courses }}
                        </th>
                    @endforeach
                </tr>
                <tr>
                    @foreach (DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name') as $courses)
                        @if (DB::table('teachers')->select('result')->count() > 0)
                            @if (DB::table('teachers')->select('result')->where('Course_name', $courses)->where('Student_email', Auth::user()->email)->count() > 0)
                                <td class="border-2 px-5 py-2 border-slate-700">
                                    {{ DB::table('teachers')->select('result')->where('Course_name', $courses)->where('Student_email', Auth::user()->email)->value('result') }}
                                </td>
                            @else
                                <td class="border-2 px-5 py-2 border-slate-700">0</td>
                            @endif
                        @else
                            <td class="border-2 px-5 py-2 border-slate-700">0</td>
                        @endif
                    @endforeach
                </tr>
            </table>

        </div>
    </div>
</x-app-layout>
