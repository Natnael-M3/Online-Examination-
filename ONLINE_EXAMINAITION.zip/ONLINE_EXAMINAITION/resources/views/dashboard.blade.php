<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard for admin') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 ">

            @if (DB::table('users')->select('Fname')->where('tags', null)->count() > 1)
                <h1 class="underline text-center">Teachers</h1><br>
                <table class="flex justify-center">
                    <tr>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            First_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            Last_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Email</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Department
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Course
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Manage
                        </th>
                    </tr>

                    @for ($i = 1;
    $i <
    DB::table('users')->select('Fname')->where('tags', null)->count();
    $i++)
                        <tr>
                            <td class="border-2 pl-2 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Fname')->where('tags', null)->pluck('Fname')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Lname')->where('tags', null)->pluck('Lname')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Depname')->where('tags', null)->pluck('Depname')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Coursename')->where('tags', null)->pluck('Coursename')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <div class="flex flex-row gap-4">
                                    <a
                                        href="/edit2/{{ DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i) }}"><i
                                            class="fas fa-edit" style="color: blue"></i>Edit</a>
                                    <a
                                        href="/delete2/{{ DB::table('users')->select('email')->where('tags', null)->pluck('email')->get($i) }}">
                                        <i class="fa fa-trash" aria-hidden="true" style="color: red"></i>
                                        Delete</a>
                                </div>

                            </td>
                        </tr>
                    @endfor

                </table><br>
            @endif


            @if (DB::table('users')->select('Fname')->where('Coursename', null)->count() > 1)
                <h1 class="underline text-center">Students</h1><br>
                <table class="flex justify-center">
                    <tr>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            First_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            Last_name</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900 ">
                            ID</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Email</th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Department
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Teachers of the student
                        </th>
                        <th class="border-2 border-slate-900 px-5 py-2 bg-teal-700 text-white  hover:bg-teal-900  ">
                            Manage
                        </th>

                    </tr>

                    @for ($i = 1;
    $i <
    DB::table('users')->select('Fname')->where('Coursename', null)->count();
    $i++)
                        <tr>
                            <td class="border-2 pl-2 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Fname')->where('Coursename', null)->pluck('Fname')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Lname')->where('Coursename', null)->pluck('Lname')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('stud_id')->where('Coursename', null)->pluck('stud_id')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{ DB::table('users')->select('Depname')->where('Coursename', null)->pluck('Depname')->get($i) }}
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                {{-- {{ DB::table('activations')->select('Teacher_email')->where('Student_email',DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i))->pluck('Teacher_email') }} --}}
                                @foreach (DB::table('activations')->select('Teacher_email')->where(
            'Student_email',
            DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i),
        )->pluck('Teacher_email') as $teacher_email)
                                    {{ $teacher_email }}/
                                @endforeach
                            </td>
                            <td class="border-2 px-5 py-1.5 border-zinc-600">
                                <div class="flex flex-row gap-4">
                                    <a
                                        href="/edit2/{{ DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i) }}"><i
                                            class="fas fa-edit" style="color: blue"></i>Edit</a>
                                    <a
                                        href="/delete3/{{ DB::table('users')->select('email')->where('Coursename', null)->pluck('email')->get($i) }}">
                                        <i class="fa fa-trash" aria-hidden="true" style="color: red"></i>
                                        Delete</a>
                                </div>

                            </td>
                        </tr>
                    @endfor
                </table><br>
            @endif

        </div>
    </div>
</x-app-layout>
