<div>
    {{ Request::segment(3) }}
    {{ Request::segment(4) }}
</div>