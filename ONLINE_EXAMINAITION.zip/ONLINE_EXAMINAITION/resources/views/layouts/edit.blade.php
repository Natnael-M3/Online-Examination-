<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>edit</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css



">
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        clifford: '#da373d',
                    }
                }
            }
        }
    </script>
    {{-- <style>
    .bg{
        border: solid 2px rebeccapurple;
        width: 100%;
        height: 100vh;
        background-image: url("https://wallpaperaccess.com/full/12313.jpg");
         background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
      
    }
  </style> --}}
</head>

<body class="bg-cover bg-no-repeat"
    style="background-image: url('https://studentprojectguide.com/wp-content/uploads/2020/07/Online-Exam-Portal.jpeg')">

    <main>
        <section class="max-h-screen  w-full bg-center bg-no-repeat bg-cover">
            <a href="/dashboard/showQuestions"><i class="fa fa-arrow-left"
                    style="color: white; margin-left:4px; margin-top:2px;" aria-hidden="true"></i></a>
            <form action="/edit/{{ $question_name }}/update" method="POST" class="formclass"
                enctype="multipart/form-data">

                @csrf
                {{-- <p class="text-white">{{$question_name}}</p> --}}
                <div class="flex flex-col gap-y-4 items-center justify-center  mt-20  ">

                    <div class="flex flex-col gap-4 sm:flex-row items-center justify-center sm:gap-x-8 w-full">
                        <label for="quetion1" class="text-white">Question :</label>
                        <input type="text" name="chooseQuestion"
                            class="bg-slate-200	 w-11/12 sm:w-1/2 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm"
                            value="{{ DB::table('questions')->select('chooseQuestion')->where('chooseQuestion', $question_name)->value('chooseQuestion') }}"
                            required>

                    </div>
                    <div class="flex flex-col items-center gap-y-4 justify-center w-full ">
                        <div class="flex flex-col sm:flex-row items-center justify-center sm:gap-x-8 gap-y-4  w-full">
                            <label for="choice1" class="text-white	">Choice A:</label>
                            <input type="text" name="choice1"
                                class="bg-slate-200	 w-4/5 sm:w-1/3 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm"
                                value="{{ DB::table('questions')->select('choice1')->where('chooseQuestion', $question_name)->value('choice1') }}"
                                required>

                        </div>
                        <div class="flex flex-col items-center sm:flex-row justify-center gap-x-8 gap-y-4  w-full">
                            <label for="choice2" class="text-white	">Choice B:</label>
                            <input type="text" name="choice2"
                                class="bg-slate-200 w-4/5 sm:w-1/3 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm"
                                value="{{ DB::table('questions')->select('choice2')->where('chooseQuestion', $question_name)->value('choice2') }}"
                                required>

                        </div>
                        <div class="flex flex-col items-center sm:flex-row justify-center gap-x-8 w-full">
                            <label for="choice3" class="text-white	">Choice C:</label>
                            <input type="text"
                                name="choice3"class="bg-slate-200 w-4/5 sm:w-1/3 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm"
                                value="{{ DB::table('questions')->select('choice3')->where('chooseQuestion', $question_name)->value('choice3') }}"
                                required>

                        </div>
                        <div class="flex flex-col items-center sm:flex-row justify-center gap-x-8 w-full">
                            <label for="choice1" class="text-white	">Choice D:</label>
                            <input type="text" name="choice4"
                                class="bg-slate-200 w-4/5 sm:w-1/3 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm"
                                value="{{ DB::table('questions')->select('choice4')->where('chooseQuestion', $question_name)->value('choice4') }}"
                                required>

                        </div>
                        <div class="flex flex-col items-center sm:flex-row justify-center gap-x-8 w-full">
                            <label for="choice1" class="text-white ">Solution :</label>
                            <input type="text" name="chooseAnswer"
                                class="bg-slate-200 w-3/5 sm:w-1/6 border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm"
                                value="{{ DB::table('questions')->select('chooseAnswer')->where('chooseQuestion', $question_name)->value('chooseAnswer') }}"
                                required>

                        </div>
                        <div
                            class="flex flex-col items-center items-center sm:flex-row justify-center md:gap-x-8  md:w-full">
                            <button value=0 name="isActivated"
                                class="text-white italic p-2 border border-indigo-500 hover:bg-white hover:text-black hover:border-inherit">insert
                                choose</button>
                        </div>
                    </div>

                    <input hidden type="text" name="Teacher_name" value="{{ Auth::user()->Fname }}">
                    <input hidden type="email" name="Teacher_email" value="{{ Auth::user()->email }}">
                    {{-- <input hidden type="text" name="Course_name" value="{{Auth::user()->Coursename}}"> --}}

                    {{-- <p name="{{Auth::user()->Fname}}" >{{Auth::user()->Fname}}</p> --}}
                </div>
            </form>

        </section>


    </main>



</body>

</html>
