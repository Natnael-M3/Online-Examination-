<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>edit</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        clifford: '#da373d',
                    }
                }
            }
        }
    </script>
    <style>
        .bg {
            width: 100%;
            height: 100vh;
            background-image: url("https://studentprojectguide.com/wp-content/uploads/2020/07/Online-Exam-Portal.jpeg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;

        }
    </style>
</head>

<body class="bg">

    <main>
        <a href="/dashboard" class="ml-3  text-white"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>

        <section class="mt-8">
            {{-- <h1 class="text-white">{{ $emails }}</h1> --}}

            @if (DB::table('users')->select('email')->where('email', $emails)->where('tags', null)->value('email') == $emails)
                {{-- <p class="text-white">hi</p> --}}
                <x-auth-card-2>
                    <form action="/edit2/{{ $emails }}/update" method="POST" class="formclass"
                        enctype="multipart/form-data">
                        @csrf
                        <div>
                            <x-label-2 for="Fname" :value="'First Name'" />

                            <x-input id="Fname" class="block mt-1 w-full" type="text" name="Fname"
                                :value="DB::table('users')
                                    ->select('Fname')
                                    ->where('email', $emails)
                                    ->value('Fname')" required autofocus />
                        </div>
                        <div>
                            <x-label-2 for="Lname" :value="'Last Name'" />

                            <x-input id="Lname" class="block mt-1 w-full" type="text" name="Lname"
                                :value="DB::table('users')
                                    ->select('Lname')
                                    ->where('email', $emails)
                                    ->value('Lname')" required autofocus />
                        </div>

                        <!-- Email Address -->
                        <div class="mt-3">
                            <x-label-2 for="email" :value="__('Email')" />

                            <x-input id="email" class="block mt-1 w-full" type="email" name="email"
                                :value="DB::table('users')
                                    ->select('email')
                                    ->where('email', $emails)
                                    ->value('email')" required />
                        </div>

                        <!-- Password -->
                        <div class="mt-3">
                            <x-label-2 for="password" :value="__('Password')" />

                            <x-input id="password" class="block mt-1 w-full" type="password" name="password" required
                                autocomplete="new-password" />
                        </div>
                        <!-- Confirm Password -->
                        <div class="mt-3">
                            <x-label-2 for="password_confirmation" :value="__('Confirm Password')" />

                            <x-input id="password_confirmation" class="block mt-1 w-full" type="password"
                                name="password_confirmation" required />
                        </div>

                        <!-- Select Option Rol type -->
                        <div class="mt-4" hidden>
                            <x-label-2 for="role_id" value="{{ __('Register as:') }}" />
                            <select name="role_id"
                                class="block bg-white w-full border border-slate-300 rounded-md py-1 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm">
                                <option value="blogwriter">Teacher</option>
                            </select>
                        </div>

                        <div class="flex items-center  justify-end mt-4">

                            {{-- <x-button class="ml-4">
                                {{ 'edit' }}
                            </x-button> --}}
                            <button
                                class="ml-8 inline-flex items-center px-4 py-2 bg-cyan-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-cyan-600 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                                Edit
                            </button>
                        </div>


                    </form>
                </x-auth-card-2>

                <!-- for student --------------------------------------------------------------------------------------------->
            @else
                <x-auth-card-2>
                    <form method="POST" action="/edit2/{{ $emails }}/update2" enctype="multipart/form-data">
                        @csrf

                        <!-- Name -->
                        <div>
                            <x-label-2 for="Fname" :value="'First Name'" />

                            <x-input id="Fname" class="block mt-0.3 w-full" type="text" name="Fname"
                                :value="DB::table('users')
                                    ->select('Fname')
                                    ->where('email', $emails)
                                    ->value('Fname')" required autofocus />
                        </div>
                        <div>
                            <x-label-2 for="Lname" :value="'Last Name'" />

                            <x-input id="Lname" class="block mt-0.3 w-full" type="text" name="Lname"
                                :value="DB::table('users')
                                    ->select('Lname')
                                    ->where('email', $emails)
                                    ->value('Lname')" required autofocus />
                        </div>
                        <!-- Student id --->
                        <div>
                            <x-label-2 for="stud_id" :value="'Student Id'" />

                            <x-input id="stud_id" class="block mt-0.3 w-full" type="text" name="stud_id"
                                :value="DB::table('users')
                                    ->select('stud_id')
                                    ->where('email', $emails)
                                    ->value('stud_id')" required autofocus />
                        </div>
                        <!-- Email Address -->
                        <div class="mt-4">
                            <x-label-2 for="email" :value="__('Email')" />

                            <x-input id="email" class="block mt-0.3 w-full" type="email" name="email"
                                :value="DB::table('users')
                                    ->select('email')
                                    ->where('email', $emails)
                                    ->value('email')" required />
                        </div>

                        <!-- Password -->
                        <div class="mt-4">
                            <x-label-2 for="password" :value="__('Password')" />

                            <x-input id="password" class="block mt-0.3 w-full" type="password" name="password" required
                                autocomplete="new-password" />
                        </div>

                        <!-- Confirm Password -->
                        <div class="mt-4">
                            <x-label-2 for="password_confirmation" :value="__('Confirm Password')" />

                            <x-input id="password_confirmation" class="block mt-0.2 w-full" type="password"
                                name="password_confirmation" required />
                        </div>
                        {{-- <div class="mt-4">
                            <x-label-2 for="addteachers" :value="'Teachers for student ( Comma Separated Email )'" />
                            <x-input id="tags" class="block mt-0.2 w-full" type="text" name="tags"
                                :value="DB::table('users')
                                    ->select('tags')
                                    ->where('email', $emails)
                                    ->value('tags')" placeholder="Example: hibst@gmail.com,alemu@hotmail.com etc"
                                required />

                        </div> --}}
                        <!-- Select Option Rol type -->
                        <div class="mt-4" hidden>
                            <x-label-2 for="role_id" value="{{ __('Register as:') }}" />
                            <select name="role_id"
                                class="block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
                                <option value="user">Student</option>
                            </select>
                        </div>

                        <div class="flex items-center justify-end mt-1.5">
                            {{-- <a href="/dashboard" class="ml-0.5 mr-28">BACK</a> --}}

                            <button
                                class="ml-14 inline-flex items-center px-4 py-1.5 bg-cyan-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-cyan-600 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                                Edit
                            </button>
                        </div>
                        {{-- <input hidden id='emails' type="text" name="emails"> --}}
                    </form>
                </x-auth-card-2>
            @endif


        </section>
    </main>
    <x-notify_messages />
</body>

</html>
