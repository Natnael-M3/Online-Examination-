{{-- <div>

    You inserted Sucessfull in to DB
    
</div> --}}
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Teacher Selections</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css
">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: '#ef3b2d',
                    },
                },
            },
        }
    </script>
</head>

<body>
    {{-- @if (DB::table('activations')->where('Student_email', Auth::user()->email)->value('isActivated') == 0 &&
    DB::table('teachers')->select('Course_name')->where('Student_email', Auth::user()->email)->where('Teacher_email', $email)->value('Course_name') == $subject)
            <p>You Inserted the exam</p> --}}
    <a href="/dashboard" class="ml-3 mt-0 text-black"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
    {{-- <p>{{ $show }}</p> --}}
    @if ($show == 1)
        <div class="flex ml-8 mr-8 flex-row justify-center h-36 mt-24  shadow-xl rounded-lg">
            <p class="mt-14">No Questions are added on this course to you</p>
        </div>
    @elseif ($show == 3)
        <div class="flex ml-8 mr-8 flex-row justify-center h-36 mt-24  shadow-xl rounded-lg">
            <p class="mt-14">You Inserted the exam or The exam is not activate by your teacher </p>
        </div>
    @elseif ($show == 4)
        <div class="flex ml-8 mr-8 flex-row justify-center h-36 mt-24  shadow-xl rounded-lg">
            <p class="mt-14">Sorry you have no teacher for this course</p>
        </div>
    @else
        <p id="countv" hidden>
            {{ $count = DB::table('questions')->where('Teacher_email', $email)->get()->count() }}</p>

        <form action="dashboard/results" method="POST" enctype="multipart/form-data">
            @csrf


            <input hidden type="text" name="Course_name" value={{ $subject }}>
            <input hidden type="text" name="Teacher_name" value={{ $Teacher_name }}>
            <input hidden type="text" name="Teacher_email" value={{ $email }}>
            <input hidden type="text" name="Student_email" value={{ $Student_email }}>
            <input hidden id='value' type="text" name="result">
            <input hidden type="text" name="Student_Fname" value="{{ Auth::user()->Fname }}">
            <input hidden type="text" name="Student_Lname" value="{{ Auth::user()->Lname }}">
            <input hidden type="text" name="Student_id" value="{{ Auth::user()->stud_id }}">
            <input hidden id='check' type="text" name="checkinserted">

            <div id="alls" class="ml-6 mt-12  sm:ml-12  shadow-2xl shadow-slate-300 w-11/12">
                @foreach (DB::table('questions')->select('chooseQuestion', 'choice1', 'choice2', 'choice3', 'choice4', 'chooseAnswer')->where('Course_Name', $subject)->get() as $selection)
                    <div class="ml-2 sm:ml-24">
                        <tr class="ml-2 sm:ml-24">
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td class="ml-2 sm:ml-24">.{{ $selection->chooseQuestion }}</td>
                        </tr>
                    </div>



                    <div id="form">
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question{{ $loop->iteration }}"
                                id="choiceA{{ $loop->iteration }}" value="A"> A.<span>
                                {{ $selection->choice1 }}</span></div>
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question{{ $loop->iteration }}"
                                id="choiceB{{ $loop->iteration }}" value="B"> B.<span>
                                {{ $selection->choice2 }}</span></div>
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question{{ $loop->iteration }}"
                                id="choiceC{{ $loop->iteration }}" value="C"> C.<span>
                                {{ $selection->choice3 }}</span></div>
                        <div class="ml-6 sm:ml-28"><input type="radio" name="question{{ $loop->iteration }}"
                                id="choiceD{{ $loop->iteration }}" value="D"> D.<span>
                                {{ $selection->choice4 }}</span></div>
                        <div hidden><span id="answer{{ $loop->iteration }}">{{ $selection->chooseAnswer }}</span>
                        </div>

                    </div>
                @endforeach
            </div>
            <div class="flex flex-row items-center justify-center">
                <button id="submit" value=0 name="isActivated"
                    class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded-full mt-6 w-1/2 sm:w-2/5">Submit</button>
            </div>

        </form>

    @endif

    <x-notify_message1 />
</body>
<script>
    document.getElementById('submit').onclick = function() {

        var inputs = document.querySelector("#form");
        var alls = document.querySelector("#alls");
        var countv = document.querySelector("#countv");
        let show = countv.innerHTML;
        let values = document.querySelector('#value');
        let check = document.querySelector('#check');

        console.log(show);
        var count = 0;
        let isclicked = 1;
        // console.log(show);
        console.log(alls.children)
        console.log(alls.children[1].children[0].children[0]);
        for (let j = 1; j < show * 2; j = j + 2) {
            for (let i = 0; i < 4; i++) {
                if (alls.children[j].children[i].children[0].type == 'radio' && alls.children[j].children[i]
                    .children[0].checked) {
                    count++;
                    console.log(count);
                }
            }
        }
        console.log(count);

        let val = 0;
        for (i = 1; i < show * 2; i = i + 2) {
            let names;
            let answer;
            for (j = 0; j < 4; j++) {
                //    console.log( alls.children[i].children[j].children[0].name);
                names = alls.children[i].children[j].children[0].name;
                if (j = 3) {
                    answer = alls.children[i].children[4].children[0].innerHTML;
                }
                // console.log(names);
                // console.log(answer);
            }

            let radios = document.getElementsByName(names)
            // console.log(radios);
            // console.log(show);
            if (count == show) {
                for (let radio of radios) {
                    if (radio.checked) {
                        if (radio.value == answer) {
                            val = val + 1;
                        }
                        // else{
                        //     alert('you do not got the answer')
                        // }  
                    }
                }
            }
        }

        if (count != show) {
            //  alert("Please fill all answers");
            isclicked = 0;
        } else {
            // alert('you Score ' + val + ' out of ' + show + ' questions ')
            isclicked = 1;
        }
        values.value = val;
        check.value = isclicked;
    }
</script>

</html>
