<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard for user') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <p hidden>
                {{ $count1 = DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->count() }}
            </p>
            @for ($i = 0; $i <= $count1 - 1; $i++)
                <a class="ml-2 bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                    href="/subject/{{ DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name')->get($i) }}">{{ DB::table('courses')->select('course_name')->where('dep_name', Auth::user()->Depname)->pluck('course_name')->get($i) }}</a>
            @endfor
</x-app-layout>
